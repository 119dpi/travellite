# MASTER → modules/runtime/GUIDE.md → LOG.md 확인 후 수정. [ENG-RUNTIME-F08]
"""Clauty promise assembly (ENGINE-CLEANUP-035): fixed shape table, no inference."""
from copy import deepcopy

from .tokenizer import PromiseLimit, fold_text


# ENGINE-CLEANUP-035 — fixed shape table of the Clauty promise (CONTRACT 약속서).
# Word category -> how its fixed operator takes neighbours. A category that is
# not listed is a mark: kept on the item to its left, never dropped, no operator.
PROMISE_SHAPES = {
    "aggregation": "aggregate", "count_stem": "aggregate", "generic_count_unit": "aggregate",
    "quantity": "quantity",
    "operator": "compare_after", "copula": "compare_after", "equivalence_operator": "compare_after",
    "threshold": "compare_before", "comparison_symbol": "compare_between",
    "negation": "negate", "exclude_stem": "negate",
    # GUIDE 원칙5: 이나 = 선택지 묶기(하나뿐이면 그대로); CONTRACT v0.12: 값 와/과 값 = OR.
    "or": "or", "or_choice": "or", "enumeration": "or", "and": "and",
    "range_start": "range_start", "range_end": "range_end",
    "arithmetic_add_operator": "arith_add", "arithmetic_mul_operator": "arith_mul",
    "command_stem": "request", "command_aux": "request", "command_end": "request",
    "request_end": "request", "request_modifier": "request", "question_end": "request",
    "presence_stem": "request", "presence_end": "request",
    # ENGINE-RULES-038 규칙 4·8·11 — 범주 자리만(낱말은 GPT Work): 사이 = range_between,
    # 없는·없음·없어 = absence (EXISTS 연산 팩이 등록돼야 켜짐, 없으면 표시),
    # 도 = list_mark (표시 — 도 붙은 조각이 둘 이상 나란하면 나열).
    "range_between": "range_between", "absence": "absent",
    # ENGINE-RULES-042 규칙 23·24·25 — 범주 자리만(낱말은 GPT Work, 연산 팩 GROUP·COMPARE·SORT가
    # 등록돼야 켜짐 — 없으면 전처럼 표시): 별 = group_by, 대비 = versus, 순 = sort_order.
    "group_by": "group", "versus": "compare", "sort_order": "sort",
    # ENGINE-RULES-049 규칙 36 — 범주 자리만(낱말은 GPT Work): 차이 = pair_compare. SUBTRACT로 바로 읽지 않는다 —
    # 규칙 36 꼴('A와 B (칸) 차이')에서만 SUBTRACT 후보를 더하고, 그 밖 자리에서는 원문 조각(그 글자 그대로).
    "pair_compare": "pair_compare",
}
# 042: shape -> operator that must be registered for the shape to work (else the word is a mark).
GATED_SHAPES = {"group": "GROUP", "compare": "COMPARE", "sort": "SORT"}
# 042 규칙 25: direction word right before 순 — fixed table (GT·GE 높은·많은 = desc, LT·LE = asc).
SORT_ORDER = {"GT": "desc", "GE": "desc", "LT": "asc", "LE": "asc"}
# 042 규칙 26: the category of 고 (빼고·제외하고의 끝) — glued to a confirm word or a value and
# followed by a condition, it may also be the short 이고 (AND): second assembly.
EXCLUDE_END = "exclude_end"
LIST_MARK_ROLES = frozenset({"list_mark"})
FIELD_MARK_ROLES = frozenset({"subject", "topic"})
# 049 규칙 36: marks the pair_compare word may carry — 이/가·은/는, 지휘관 10/28 ② 을/를.
PAIR_MARK_ROLES = FIELD_MARK_ROLES | {"object"}
SCOPE_MARK_ROLES = frozenset({"range_link"})
UNIT_MARK_ROLE = "number_unit"  # 038 규칙 6·039 규칙 12·13: 값 바로 뒤 단위 표시(원·명·%·개 …)
PROMISE_SCHEMA = "clauty_promise_1"
# ENGINE-RULES-038 구조 상수(낱말 아님 — 등록 낱말이 아니므로 words의 expression_id = null):
# 규칙 2 쉼표 = 와/과와 같은 나열, 규칙 4 값~값 = 범위, 규칙 5 부정+비교 = 반대 비교(수학 고정표).
COMMAS = frozenset({",", "、", "，"})
RANGE_TILDE = "~"
FLIPPED_COMPARE = {"GT": "LE", "GE": "LT", "LT": "GE", "LE": "GT"}
LOWER_COMPARE = frozenset({"GE", "GT"})
UPPER_COMPARE = frozenset({"LE", "LT"})
# ENGINE-RULES-047 규칙 33 (구조 상수 — 낱말 아님): 짝이 맞는 괄호 안이 값·산술 낱말(과 그 안의 같은 괄호)만으로
# 빈틈없이 덮이고 바깥 바로 옆이 산술 낱말이면, 그 안을 먼저 F 단계로 조립해 값 하나처럼 바깥 산술의 인자로 쓴다.
# 괄호 글자는 전처럼 맨 위 marks(punct)에 남는다(새 노드 종류 없음). 그 밖 괄호(매장(강남)·(주)·짝 없는 괄호)는 그대로.
PAREN_OPEN, PAREN_CLOSE = "(", ")"
ARITH_SHAPES = frozenset({"arith_add", "arith_mul"})
# ENGINE-RULES-049 규칙 36 (지휘관 설계): 뒤붙이 비교 쌍의 고정 연산 — 수학 고정(빼기), 해석 아님. 말한 순서 X − Y.
PAIR_COMPARE_OP = "SUBTRACT"


def _structure_ref(piece):
    """A structure character (comma, ~) standing where a connective word stands."""
    return {"text": piece["text"], "start": piece["start"], "end": piece["end"], "expression_id": None}


def _ref(piece):
    return {"text": piece["text"], "start": piece["start"], "end": piece["end"],
            "expression_id": piece["expression_id"]}


def _mark(piece):
    return {"text": piece["text"], "start": piece["start"], "end": piece["end"],
            "role": piece.get("category", piece["kind"])}


class PromiseAssembler:
    """ENGINE-CLEANUP-035: one reading -> formulas by the fixed shape table.

    No host names, no slot IDs, no meaning of text pieces. Stages (CONTRACT 약속서):
    A text-piece OR/AND, B conditions, C condition OR/AND, D FILTER/phrase,
    E aggregation (both sides -> two candidates), F arithmetic, G leftovers.
    """

    MAX_CANDIDATES = 32

    def __init__(self, registry):
        self.operators = frozenset(registry.operators)
        # Registered two-word operator pairs (e.g. 앞+자리 -> STARTS_WITH).
        self.pairs = {}
        for rule in registry.active_rules("compound"):
            semantic = rule.get("semantic") or {}
            if len(rule["parts"]) == 2 and semantic.get("kind") == "operator":
                self.pairs[tuple(rule["parts"])] = semantic["operator_id"]

    # -- items -----------------------------------------------------------------
    @staticmethod
    def _op(op, args, words, **extra):
        node = {"kind": "op", "op": op, "words": words, "args": args}
        node.update(extra)
        return node

    @staticmethod
    def _add_marks(target, marks):
        if marks:
            target.setdefault("marks", []).extend(marks)

    @staticmethod
    def _list_comma(reading, index):
        """038 규칙 2: the comma at index stands between two bare pieces (a text/value
        piece right before it, and right after it one that carries no 이/가·은/는) —
        and is not numbers written together with a comma (1,2·1,00 — 1,000 is one value since 040 규칙 21)."""
        piece = reading[index]
        if piece["kind"] != "punct" or piece["text"] not in COMMAS or index == 0 or index + 1 >= len(reading):
            return False
        left, right = reading[index - 1], reading[index + 1]
        if left["kind"] not in {"text", "value"} or right["kind"] != left["kind"]:
            return False  # same kind on both sides (조각, 조각 / 값, 값) — 같은 자리
        if (left["kind"] == "value" and right["kind"] == "value" and left["end"] == piece["start"]
                and piece["end"] == right["start"]):
            return False
        after = reading[index + 2] if index + 2 < len(reading) else None
        if after is not None and after["kind"] == "word" and after["start"] == right["end"] \
                and after["category"] in FIELD_MARK_ROLES:
            # 이/가 starts a clause (일단, 이름이 …) — unless a negation word follows (규칙 3).
            negation = reading[index + 3] if index + 3 < len(reading) else None
            return (negation is not None and negation["kind"] == "word"
                    and PROMISE_SHAPES.get(negation["category"]) == "negate")
        return True

    def _items(self, reading, list_commas=False, and_go=frozenset()):
        items, request, root_marks = [], [], []

        def attach(mark):
            for item in reversed(items):
                if item["t"] == "sep":
                    break
                holder = item if item["t"] == "word" else item["node"]
                holder.setdefault("marks", []).append(mark)
                return
            root_marks.append(mark)

        index = 0
        while index < len(reading):
            piece = reading[index]
            kind = piece["kind"]
            nxt_piece = reading[index + 1] if index + 1 < len(reading) else None
            if list_commas and self._list_comma(reading, index):
                # 038 규칙 2: in the list assembly a comma between two pieces is the 와/과 list.
                items.append({"t": "word", "shape": "or", "op": "OR", "category": "punct",
                              "words": [_structure_ref(piece)]})
                index += 1
                continue
            if (kind == "text" and fold_text(piece["text"]) == RANGE_TILDE and items and items[-1]["t"] == "term"
                    and items[-1]["node"]["kind"] == "value" and nxt_piece is not None
                    and nxt_piece["kind"] == "value"):
                # 038 규칙 4: value~value is a range.
                items.append({"t": "word", "shape": "range_tilde", "op": "AND", "category": "range_tilde",
                              "words": [_structure_ref(piece)]})
                index += 1
                continue
            if kind in {"text", "value"}:
                node = {k: piece[k] for k in ("kind", "text", "start", "end")}
                if kind == "value":
                    node = {"kind": "value", "matcher": piece["matcher"], "value": piece["value"],
                            "text": piece["text"], "start": piece["start"], "end": piece["end"]}
                # spaced: written apart from the piece before it (whitespace, not a word).
                spaced = index == 0 or reading[index - 1]["end"] < piece["start"]
                items.append({"t": "term", "node": node, "spaced": spaced})
            elif kind == "punct":
                group = self._paren_group(reading, index) if piece["text"] == PAREN_OPEN else None
                if group:
                    # 047 규칙 33: (1200+800)*2 — the inside is one value-like item of the outer arithmetic.
                    node, close = group
                    root_marks.extend(_mark(p) for p in reading[index:close + 1] if p["kind"] == "punct")
                    items.append({"t": "unit", "node": node})
                    index = close + 1
                    continue
                root_marks.append(_mark(piece))
                items.append({"t": "sep"})
            else:
                nxt = reading[index + 1] if index + 1 < len(reading) else None
                pair = (self.pairs.get((piece["category"], nxt["category"]))
                        if nxt is not None and nxt["kind"] == "word" else None)
                if pair:
                    items.append({"t": "word", "shape": "compare_between", "op": pair,
                                  "category": "pair", "words": [_ref(piece), _ref(nxt)]})
                    index += 2
                    continue
                if (piece["start"], piece["end"]) in and_go:
                    # 042 규칙 26 (second assembly): 퇴사고 휴직인 = 퇴사이고 휴직인.
                    items.append({"t": "word", "shape": "and", "op": "AND", "category": "and",
                                  "words": [_ref(piece)]})
                    index += 1
                    continue
                shape = PROMISE_SHAPES.get(piece["category"], "mark")
                if shape == "pair_compare":
                    # 049 규칙 36: a pair_compare word is a text piece of its own letters (as an unregistered
                    # or confirm word would be — 목표 대비 차이 keeps COMPARE(목표, 차이)); only the rule-36
                    # assembly (_stage_pair_compare) turns it into SUBTRACT.
                    node = {"kind": "text", "text": piece["text"], "start": piece["start"], "end": piece["end"]}
                    spaced = index == 0 or reading[index - 1]["end"] < piece["start"]
                    items.append({"t": "term", "node": node, "spaced": spaced, "pair_word": _ref(piece)})
                    index += 1
                    continue
                if shape in GATED_SHAPES and GATED_SHAPES[shape] not in self.operators:
                    shape = "mark"  # 042: no GROUP/COMPARE/SORT pack yet -> as before (표시)
                if shape == "mark":
                    attach(_mark(piece))
                elif shape == "request":
                    request.append(_mark(piece))
                else:
                    semantic = piece.get("semantic") or {}
                    op = {"or": "OR", "and": "AND", "quantity": "COUNT", "negate": "NOT",
                          "range_start": "GE", "range_end": "LE", **GATED_SHAPES}.get(
                              shape, semantic.get("operator_id"))
                    items.append({"t": "word", "shape": shape, "op": op, "category": piece["category"],
                                  "words": [_ref(piece)]})
            index += 1
        return items, request, root_marks

    @staticmethod
    def _arith_word(piece):
        return (piece is not None and piece["kind"] == "word"
                and PROMISE_SHAPES.get(piece["category"]) in ARITH_SHAPES)

    @staticmethod
    def _incomplete(node):
        stack = [node]
        while stack:
            current = stack.pop()
            if current.get("incomplete"):
                return True
            stack.extend(current.get("args", ()))
        return False

    def _paren_inside(self, reading, open_index):
        """047 규칙 33: (node, index of the matching ')') when the inside of the '(' at open_index
        is only values, arithmetic words and inner groups of the same kind, and assembles (F) to
        one complete item; else None (an unmatched '(' never closes by guess)."""
        items, k = [], open_index + 1
        while k < len(reading):
            piece = reading[k]
            if piece["kind"] == "punct" and piece["text"] == PAREN_CLOSE:
                break
            if piece["kind"] == "value":
                node = {"kind": "value", "matcher": piece["matcher"], "value": piece["value"],
                        "text": piece["text"], "start": piece["start"], "end": piece["end"]}
                items.append({"t": "term", "node": node, "spaced": True})
            elif (piece["kind"] == "word" and piece.get("category") == UNIT_MARK_ROLE and items
                  and items[-1]["t"] == "term" and items[-1]["node"]["kind"] == "value"
                  and reading[k - 1]["end"] == piece["start"]):
                # 지휘관 047 E: a unit mark glued to the value (3만원·2만엔·3명) keeps it a value.
                items[-1]["node"].setdefault("marks", []).append(_mark(piece))
            elif self._arith_word(piece):
                items.append({"t": "word", "shape": PROMISE_SHAPES[piece["category"]],
                              "op": (piece.get("semantic") or {}).get("operator_id"),
                              "category": piece["category"], "words": [_ref(piece)]})
            elif piece["kind"] == "punct" and piece["text"] == PAREN_OPEN:
                inner = self._paren_inside(reading, k)
                if inner is None:
                    return None
                items.append({"t": "unit", "node": inner[0]})
                k = inner[1] + 1
                continue
            else:
                return None
            k += 1
        else:
            return None
        if not items:
            return None
        self._stage_arithmetic(items)
        if len(items) != 1 or self._incomplete(items[0]["node"]):
            return None
        return items[0]["node"], k

    def _paren_group(self, reading, open_index):
        """047 규칙 33: the group at open_index when it stands right next to an outer arithmetic word."""
        group = self._paren_inside(reading, open_index)
        if group is None:
            return None
        before = reading[open_index - 1] if open_index > 0 else None
        after = reading[group[1] + 1] if group[1] + 1 < len(reading) else None
        return group if self._arith_word(before) or self._arith_word(after) else None

    def _word_to_mark(self, items, i, root_marks):
        word = items.pop(i)
        marks = [{"text": w["text"], "start": w["start"], "end": w["end"], "role": word["category"]}
                 for w in word["words"]] + word.get("marks", [])
        for item in reversed(items[:i]):
            if item["t"] == "sep":
                break
            holder = item if item["t"] == "word" else item["node"]
            holder.setdefault("marks", []).extend(marks)
            return
        root_marks.extend(marks)

    @staticmethod
    def _eligible_field(item):
        if item is None or item["t"] != "term":
            return False
        return {m["role"] for m in item["node"].get("marks", [])} <= FIELD_MARK_ROLES

    def _cond(self, word, args, field=None, incomplete=False):
        node = self._op(word["op"], args, word["words"], field=field)
        if incomplete:
            node["incomplete"] = True
        self._add_marks(node, word.get("marks"))
        return {"t": "cond", "node": node}

    # -- stages ----------------------------------------------------------------
    def _stage_list_marks(self, items, eids):
        """038 규칙 11 자리: two or more pieces in a row each ending in a list_mark word
        (휴직도 재직도) are one list, like 와/과 (OR); the 도 words move to the list."""
        def ends_in_mark(item):
            marks = item["node"].get("marks", []) if item["t"] == "term" else []
            return bool(marks) and marks[-1]["role"] in LIST_MARK_ROLES
        i = 0
        while i < len(items):
            j = i
            while j < len(items) and ends_in_mark(items[j]):
                j += 1
            if j - i >= 2:
                nodes, words = [], []
                for item in items[i:j]:
                    node = item["node"]
                    mark = node["marks"].pop()
                    if not node["marks"]:
                        del node["marks"]
                    words.append({"text": mark["text"], "start": mark["start"], "end": mark["end"],
                                  "expression_id": eids.get((mark["start"], mark["end"]))})
                    nodes.append(node)
                items[i:j] = [{"t": "term", "node": self._op("OR", nodes, words), "list_mark": True}]
            i += 1

    @staticmethod
    def _scope_point(items, i):
        """038 규칙 3: an OR/list word at i whose right piece carries 이/가·은/는 and is
        followed right away by a negation word (휴직 또는 재직이 아닌)."""
        word = items[i]
        after = items[i + 2] if i + 2 < len(items) else None
        return (word["t"] == "word" and word["shape"] == "or" and 0 < i and i + 1 < len(items)
                and items[i - 1]["t"] == "term" and items[i + 1]["t"] == "term"
                and bool({m["role"] for m in items[i + 1]["node"].get("marks", [])} & FIELD_MARK_ROLES)
                and after is not None and after["t"] == "word" and after["shape"] == "negate")

    @staticmethod
    def _same_block(items, k, end_text=None, last=False):
        """048 규칙 35: items[k], items[k+1] are one block 'piece + end piece' — a text piece or
        value, then a text piece written apart from it (권역 in 김성순 권역). No marks on the piece;
        the end piece carries none either, except the last block's end may keep marks other than
        이/가·은/는. end_text: the end piece must have exactly this text (같은 끝 조각)."""
        if k < 0 or k + 1 >= len(items):
            return False
        piece, end = items[k], items[k + 1]
        if piece["t"] != "term" or end["t"] != "term" or "same_shape" in piece or "same_shape" in end:
            return False
        if piece["node"]["kind"] not in {"text", "value"} or end["node"]["kind"] != "text":
            return False
        if piece["node"].get("marks") or not end["spaced"]:
            return False
        roles = {m["role"] for m in end["node"].get("marks", [])}
        if roles and (not last or roles & FIELD_MARK_ROLES):
            return False
        return end_text is None or end["node"]["text"] == end_text

    def _stage_same_shape(self, items):
        """048 규칙 35 (its own later assembly — the first assembly, neighbour pieces one by one,
        stays first): a list word (shape or) between two same-shape blocks, X E 와 Y E with the
        end piece E written exactly the same, -> OR([X E], [Y E]) (each a phrase). Several
        same-shape blocks joined by the same list word -> one OR. Not when a list word stands
        right before the first block or right after the last one (a mixed list). Returns
        whether it joined anything (no join -> no extra candidate)."""
        def is_list(x, op):
            return x["t"] == "word" and x["shape"] == "or" and x["op"] == op

        joined = False
        i = 2
        while i + 2 < len(items):
            word = items[i]
            if not (word["t"] == "word" and word["shape"] == "or" and self._same_block(items, i - 2)
                    and not (i >= 3 and is_list(items[i - 3], word["op"]))):
                i += 1
                continue
            end_text = items[i - 1]["node"]["text"]
            starts, j = [i - 2], i  # j: the list word after the last block so far
            while (j + 2 < len(items) and is_list(items[j], word["op"])
                   and self._same_block(items, j + 1, end_text, last=True)):
                starts.append(j + 1)
                j += 3
            if (len(starts) < 2 or any(items[k + 1]["node"].get("marks") for k in starts[:-1])
                    or (j < len(items) and is_list(items[j], word["op"]))):
                i += 1
                continue
            args = [{"kind": "phrase", "items": [items[k]["node"], items[k + 1]["node"]]} for k in starts]
            node = self._op(word["op"], args, [w for k in starts[1:] for w in items[k - 1]["words"]])
            for k in starts[1:]:
                self._add_marks(node, items[k - 1].get("marks"))
            items[i - 2:j] = [{"t": "term", "node": node, "same_shape": True}]
            joined = True
            i -= 1
        return joined

    def _stage_pair_compare(self, items):
        """049 규칙 36 (its own later assembly — earlier candidates stay as they are): after stage A the
        items are exactly [plain pieces/values before it, kept outside — 지휘관 10/28] [OR or AND with exactly two args (038 나열 — 와/과·또는·이나·혹은·쉼표 — or 규칙 35
        blocks)] [text pieces F … written apart, no marks] [pair_compare word P written apart, marks only
        이/가·은/는·을/를] (+ punctuation; request words are already apart) -> SUBTRACT([X F…], [Y F…]) in the
        order spoken (no F -> SUBTRACT(X, Y); a 규칙 35 block X = [A 권역] is spread: [A 권역 F…]).
        words = the list words + P. Anything else in the sentence (another word such as 대비 — 칸 이름
        보호 ②, a condition, a piece before the list, a 도 list, three items) -> not this shape. Returns
        whether it built (no build -> no extra candidate)."""
        if PAIR_COMPARE_OP not in self.operators:
            return False
        n = len(items)
        while n and items[n - 1]["t"] == "sep":
            n -= 1
        if n < 2:
            return False
        pair = items[n - 1]
        if (pair["t"] != "term" or "pair_word" not in pair or not pair["spaced"]
                or {m["role"] for m in pair["node"].get("marks", [])} - PAIR_MARK_ROLES):
            return False
        # 지휘관 10/28 ③: plain pieces/values before the list (이번 달·3분기) stay outside SUBTRACT, as
        # stage D leaves pieces before a result ([이번 달] ; SUBTRACT(…)) — no word or marked piece among them.
        h = 0
        while h < n - 1 and items[h]["t"] == "term" and "pair_word" not in items[h] and (
                items[h]["node"]["kind"] in {"text", "value"}
                and {m["role"] for m in items[h]["node"].get("marks", [])} <= {UNIT_MARK_ROLE}
                and (items[h]["node"]["kind"] == "value" or not items[h]["node"].get("marks"))):
            h += 1
        head = items[h] if h < n - 1 else {"t": None}
        node = head["node"] if head["t"] == "term" else {}
        if (head.get("list_mark") or node.get("kind") != "op" or node.get("op") not in {"OR", "AND"}
                or len(node["args"]) != 2 or (h and not head.get("spaced", True))):
            return False
        fields = items[h + 1:n - 1]
        if any(x["t"] != "term" or x["node"]["kind"] != "text" or x["node"].get("marks") or not x["spaced"]
               or "pair_word" in x for x in fields):
            return False  # 대비·조건·값·표시 붙은 조각이 끼면 이 꼴이 아니다
        if n >= 2 and items[n - 2]["t"] == "word" and items[n - 2]["shape"] == "compare":
            return False  # 칸 이름 보호 ②: 바로 앞 대비(목표 대비 차이) — 위 꼴 검사로도 이미 막힘

        def side(x):
            if not fields:
                return deepcopy(x)
            parts = x["items"] if x["kind"] == "phrase" else [x]
            return {"kind": "phrase", "items": deepcopy(parts) + [deepcopy(f["node"]) for f in fields]}
        built = self._op(PAIR_COMPARE_OP, [side(a) for a in node["args"]],
                         list(node["words"]) + [pair["pair_word"]])
        self._add_marks(built, node.get("marks"))
        self._add_marks(built, pair["node"].get("marks"))
        items[h:n] = [{"t": "unit", "node": built}]
        return True

    def _stage_terms(self, items, root_marks, eids, negation_scope=False, same_shape=False):
        """A: OR/AND whose both neighbours are text pieces/values. A right piece
        carrying 이/가·은/는 starts its own clause, so it waits for stage C —
        except, in the negation-scope assembly (038 규칙 3), right before a negation.
        048 규칙 35: in the same-shape assembly, same-shape blocks are joined first;
        returns whether that joined anything."""
        self._stage_list_marks(items, eids)
        joined = self._stage_same_shape(items) if same_shape else False
        chained = set()
        i = 1
        while i < len(items) - 1:
            word = items[i]
            after = items[i + 2] if i + 2 < len(items) else None
            if (word["t"] == "word" and word["category"] == "enumeration" and after is not None
                    and after["t"] == "word" and after["shape"] == "range_between"):
                i += 1  # 038 규칙 4: A와 B 사이 is a range (stage B), not a list.
                continue
            if (word["t"] == "word" and word["shape"] in {"or", "and"}
                    and items[i - 1]["t"] == "term" and items[i + 1]["t"] == "term"
                    and (not {m["role"] for m in items[i + 1]["node"].get("marks", [])} & FIELD_MARK_ROLES
                         # 038 규칙 3: 휴직이나 재직이 아닌 — the list is joined and the
                         # negation then covers the whole list (NOT(OR(휴직, 재직))).
                         or (negation_scope and self._scope_point(items, i)))):
                left, right = items[i - 1]["node"], items[i + 1]["node"]
                if id(left) in chained and left["op"] == word["op"]:
                    left["args"].append(right)
                    left["words"].extend(word["words"])
                    node = left
                else:
                    node = self._op(word["op"], [left, right], list(word["words"]))
                    chained.add(id(node))
                self._add_marks(node, word.get("marks"))
                items[i - 1:i + 2] = [{"t": "term", "node": node}]
                continue
            i += 1
        # 원칙5 "하나뿐이면 그대로": a text piece/value on the left and no text
        # piece/value on the right can never be joined -> the word is a mark.
        i = 1
        while i < len(items):
            word = items[i]
            if (word["t"] == "word" and word["shape"] in {"or", "and"} and items[i - 1]["t"] == "term"
                    and (i + 1 == len(items) or items[i + 1]["t"] != "term")):
                self._word_to_mark(items, i, root_marks)
                continue
            i += 1
        return joined

    def _stage_flips(self, items):
        """038 규칙 5: a negation word right next to a comparison word (부정+비교 안 넘는,
        or an unmarked 비교+부정 넘지 않는) is one comparison with the opposite operator
        (fixed table GT<->LE, GE<->LT — 수학 고정, 해석 아님)."""
        i = 0
        while i < len(items) - 1:
            a, b = items[i], items[i + 1]
            if a["t"] == "word" and b["t"] == "word" and not a.get("marks"):
                pair = None
                if a["category"] == "negation" and b["shape"] == "compare_after" and b["op"] in FLIPPED_COMPARE:
                    pair = b["op"]
                elif b["category"] == "negation" and a["shape"] == "compare_after" and a["op"] in FLIPPED_COMPARE:
                    pair = a["op"]
                if pair:
                    word = {"t": "word", "shape": "compare_after", "op": FLIPPED_COMPARE[pair],
                            "category": "operator", "words": a["words"] + b["words"]}
                    self._add_marks(word, b.get("marks"))
                    items[i:i + 2] = [word]
            i += 1

    def _stage_sorts(self, items):
        """042 규칙 25: [칸] [방향 비교 낱말] 순 -> SORT(칸) with order from the fixed table
        SORT_ORDER (높은·많은 = desc, 낮은·적은 = asc — 수학 고정, 해석 아님); [칸] 순 (매출순)
        -> SORT(칸), order null. A COUNT word in the field place counts its left run first (039
        규칙 14 — 직원 수 많은 순). No field -> incomplete. SORT is its own item (no FILTER/집계)."""
        i = 0
        while i < len(items):
            word = items[i]
            if word["t"] != "word" or word["shape"] != "sort":
                i += 1
                continue
            lo, words, marks, order = i, list(word["words"]), [], None
            before = items[i - 1] if i > 0 else None
            if (before is not None and before["t"] == "word" and before["shape"] == "compare_after"
                    and before["op"] in SORT_ORDER):
                lo, order = i - 1, SORT_ORDER[before["op"]]
                words, marks = before["words"] + words, list(before.get("marks", []))
            size = len(items)
            if lo >= 1 and self._count_field(items, lo - 1) is not None:
                lo, i = lo - (size - len(items)), i - (size - len(items))
            field = items[lo - 1] if lo >= 1 and self._eligible_field(items[lo - 1]) else None
            node = self._op("SORT", [field["node"]] if field else [], words, order=order)
            if field is None:
                node["incomplete"] = True
            self._add_marks(node, marks + word.get("marks", []))
            first = lo - 1 if field else lo
            items[first:i + 1] = [{"t": "solo", "node": node}]
            i = first + 1

    @staticmethod
    def _stage_groups(items):
        """042 규칙 23: 별 -> GROUP(the item on its left — after stage D, a piece, a phrase of
        pieces written apart, or a FILTER result). It is its own item: aggregation and
        arithmetic do not take it (권역별 매출 합계 = GROUP(권역) ; SUM(매출)). No left -> incomplete."""
        i = 0
        while i < len(items):
            word = items[i]
            if word["t"] == "word" and word["shape"] == "group":
                left = items[i - 1] if i > 0 and items[i - 1]["t"] in {"term", "phrase", "unit"} else None
                node = PromiseAssembler._op("GROUP", [left["node"]] if left else [], word["words"])
                if left is None:
                    node["incomplete"] = True
                PromiseAssembler._add_marks(node, word.get("marks"))
                items[i - 1 if left else i:i + 1] = [{"t": "solo", "node": node}]
                i = i if left else i + 1
                continue
            i += 1

    @staticmethod
    def _stage_compares(items):
        """042 규칙 24: A 대비 B -> COMPARE(A, B), the items on both sides (like F 산술 —
        조건은 값이 아니므로 제외); A 대비 -> COMPARE(A). No A -> incomplete (B left alone).
        The engine does not compute or split B (지난달 대비 이번 달 매출 = COMPARE(지난달,
        [이번 달 매출]) — 두 기간 값·칸 나누기는 클로티)."""
        ok = lambda x: x["t"] in {"term", "phrase", "unit"}
        i = 0
        while i < len(items):
            word = items[i]
            if word["t"] == "word" and word["shape"] == "compare":
                left = items[i - 1] if i > 0 and ok(items[i - 1]) else None
                right = items[i + 1] if left and i + 1 < len(items) and ok(items[i + 1]) else None
                node = PromiseAssembler._op("COMPARE", [x["node"] for x in (left, right) if x], word["words"])
                if left is None:
                    node["incomplete"] = True
                PromiseAssembler._add_marks(node, word.get("marks"))
                lo = i - 1 if left else i
                items[lo:(i + 2 if right else i + 1)] = [{"t": "unit", "node": node}]
                i = lo + 1
                continue
            i += 1

    def _range_at(self, items, i):
        """038 규칙 4: (a, b, lower_words, join_words, upper_word) for the range ending
        at the word i, or None. Forms: A부터 B까지 (전과 같음) · A{에서} B까지 ·
        A부터 B 사이 · A{에서} B 사이 · A와/과 B 사이 · 값~값."""
        word = items[i]
        term = lambda k: 0 <= k < len(items) and items[k]["t"] == "term"
        if word["t"] != "word":
            return None
        if word["shape"] == "range_tilde":
            if term(i - 1) and term(i + 1):
                return i - 1, i + 1, [], word["words"], None
            return None
        if word["shape"] not in {"range_end", "range_between"} or not term(i - 1):
            return None
        before = items[i - 2] if i >= 2 else None
        if before is not None and before["t"] == "word" and term(i - 3):
            if before["shape"] == "range_start":
                return i - 3, i - 1, before, [], word
            if before["category"] == "enumeration" and word["shape"] == "range_between":
                return i - 3, i - 1, None, before["words"], word
        if term(i - 2):
            node = items[i - 2]["node"]
            marks = node.get("marks", [])
            # A에서 (glued range_link suffix only — a spaced 중 is not a range start). 039 규칙 12:
            # unit marks glued in between (50%에서·3만원에서) do not hide the glued 에서.
            glued_end = node.get("end")
            for mark in marks[:-1]:
                if mark["role"] == UNIT_MARK_ROLE and mark["start"] == glued_end:
                    glued_end = mark["end"]
            if marks and marks[-1]["role"] in SCOPE_MARK_ROLES and marks[-1]["start"] == glued_end:
                return i - 2, i - 1, None, [], word
        return None

    def _stage_conditions(self, items, root_marks):
        """B: ranges, comparisons, negation, 몇+unit."""
        self._stage_flips(items)
        self._stage_sorts(items)
        i = 0
        while i < len(items):
            found = self._range_at(items, i)
            if found:
                a, b, lower_word, join_words, upper_word = found
                # 040 규칙 18: a counting word right before the range (직원 수가 3에서 5 사이,
                # 직원 몇 명 3~5) -> COUNT(pieces on its left) is the field of both bounds.
                shift = self._count_before(items, a - 1)
                a, b, i = a - shift, b - shift, i - shift
                has_field = a > 0 and self._eligible_field(items[a - 1])
                field = items[a - 1]["node"] if has_field else None
                lower = self._op("GE", [items[a]["node"]], lower_word["words"] if lower_word else [],
                                 field=deepcopy(field))
                upper = self._op("LE", [items[b]["node"]], upper_word["words"] if upper_word else [],
                                 field=deepcopy(field))
                if lower_word:
                    self._add_marks(lower, lower_word.get("marks"))
                if upper_word:
                    self._add_marks(upper, upper_word.get("marks"))
                first = a - 1 if has_field else a
                last = max(b, i)
                items[first:last + 1] = [{"t": "cond", "node": self._op("AND", [lower, upper], list(join_words))}]
                i = first + 1
                continue
            i += 1
        i = 0
        while i < len(items):
            word = items[i]
            if word["t"] == "word" and word["shape"] in {"range_start", "range_end", "range_between",
                                                         "range_tilde"}:
                self._word_to_mark(items, i, root_marks)
                continue
            i += 1
        return [(self._stage_bounds(branch), marks)
                for branch, marks in self._conditions_from(items, root_marks, 0)]

    def _stage_bounds(self, items):
        """038 규칙 4(A 이상 B 이하): a lower comparison right before an upper one
        that has no field of its own -> AND, the upper one sharing the lower's field."""
        i = 0
        while i < len(items) - 1:
            a, b = items[i], items[i + 1]
            if (a["t"] == "cond" and b["t"] == "cond" and a["node"]["op"] in LOWER_COMPARE
                    and b["node"]["op"] in UPPER_COMPARE and "field" in a["node"]
                    and b["node"].get("field") is None and len(b["node"]["args"]) == 1
                    and len(a["node"]["args"]) == 1 and not a["node"].get("incomplete")
                    and {a["node"]["args"][0]["kind"], b["node"]["args"][0]["kind"]} <= {"value", "text"}
                    and not b["node"].get("incomplete")):
                b["node"]["field"] = deepcopy(a["node"]["field"])
                items[i:i + 2] = [{"t": "cond", "node": self._op("AND", [a["node"], b["node"]], [])}]
            i += 1
        return items

    @staticmethod
    def _bare(item):
        return item["t"] == "term" and not item["node"].get("marks")

    def _compare_spans(self, items, i):
        """(field_lo, field_hi, value_lo) spans for a compare_after word at i whose
        left item is a term. The first span is the old reading (field = the item
        just before the value when eligible). 동결 전 수정 — the promise gives every
        assembly (약속서 3): when a term carrying 이/가·은/는 stands before a run of
        bare terms, the terms after it up to the word are the value (직책이 매장
        매니저인), and bare terms right before it may belong to the field (이마트
        사번이·근무 상태가). Spans only; the engine never says which one is meant."""
        before = items[i - 2] if i > 1 else None
        if (before is not None and before["t"] == "term" and before["node"]["kind"] == "value"
                and not before["node"].get("marks") and items[i - 1].get("spaced") is False
                and items[i - 1]["node"]["kind"] == "text"):
            # 039 규칙 15: letters glued right after a value (10월·1등·0x64) stay with that
            # value — one chunk is never split into field and value (E1). A bare piece
            # before it is not made the field (날짜·순위에는 칸+값 비교를 짓지 않음);
            # a piece carrying 이/가·은/는 still is (전과 같은 칸 표시).
            marked = i > 2 and self._eligible_field(items[i - 3]) and bool(items[i - 3]["node"].get("marks"))
            spans = [(i - 3, i - 2, i - 2) if marked else (i - 2, i - 2, i - 2)]
        else:
            # 039 규칙 15: a bare piece + value (단위 표시 포함: 100%·3만원·3개) + 비교 =
            # CMP(piece, value) — the first assembly as before.
            has_field = i > 1 and self._eligible_field(items[i - 2])
            spans = [(i - 2, i - 1, i - 1) if has_field else (i - 1, i - 1, i - 1)]

        def spaced(left, right):
            # Only pieces written apart, or letters right after a value (1억), are
            # grouped: letters glued in one chunk already come whole from the
            # reader (근무상태가 -> 근무상태), letters+digits too (파트너1, E3).
            a, b = items[left], items[right]
            return a.get("spaced") is not None and b.get("spaced") is not None and (
                b["spaced"] or a["node"]["kind"] == "value")

        j = i - 2
        while j >= 0 and self._bare(items[j]) and spaced(j, j + 1):
            j -= 1
        if j < 0 or items[j]["t"] != "term" or not items[j]["node"].get("marks") \
                or not self._eligible_field(items[j]):
            return spans
        k = j
        while k > 0 and self._bare(items[k - 1]) and spaced(k - 1, k):
            k -= 1
        for lo in range(j, k - 1, -1):
            span = (lo, j + 1, j + 1)
            if span not in spans:
                spans.append(span)
        return spans

    def _count_field(self, items, k):
        """039 규칙 14: items[k] is a counting word (COUNT — 수·개수, 몇+단위) right before a
        comparison's field place. The run of pieces on its left becomes COUNT(run) as one
        field-able item; returns its index, or None when the word is no COUNT, there is no
        run, or a condition stands before the run (휴직인 직원 수 … — FILTER 대상, 전과 같음)."""
        word = items[k] if 0 <= k < len(items) else None
        if (word is None or word["t"] != "word" or word["shape"] not in {"aggregate", "quantity"}
                or word["op"] != "COUNT"):
            return None
        a = k
        while a > 0 and items[a - 1]["t"] == "term":
            a -= 1
        if a == k or (a > 0 and items[a - 1]["t"] == "cond"):
            return None
        extra = {"unit": word["unit"]} if "unit" in word else {}
        node = self._op("COUNT", [self._group(items[a:k])], word["words"], **extra)
        self._add_marks(node, word.get("marks"))
        items[a:k + 1] = [{"t": "term", "node": node, "spaced": None}]
        return a

    # 040 규칙 18: words that become a condition in stage B (휴직인 직원 수 … — the run is that
    # condition's FILTER 대상, as in 039 규칙 14 where the condition is already built).
    CONDITION_SHAPES = frozenset({"compare_after", "compare_before", "compare_between", "negate", "absent"})

    def _count_before(self, items, k):
        """040 규칙 18: _count_field for a range starting at k + 1 — 몇 takes its unit piece
        first (몇 명, as stage B does later for comparisons). Not when a condition word or a
        condition stands right before the counted run (전과 같음). Returns how many items
        fewer there are before k + 1 (0 when nothing changed)."""
        quantity = (k >= 1 and items[k]["t"] == "term" and items[k]["node"]["kind"] == "text"
                    and items[k - 1]["t"] == "word" and items[k - 1]["shape"] == "quantity"
                    and "unit" not in items[k - 1])
        word = k - 1 if quantity else k
        if not (0 <= word < len(items)) or items[word]["t"] != "word" or items[word]["op"] != "COUNT" \
                or items[word]["shape"] not in {"aggregate", "quantity"}:
            return 0
        a = word
        while a > 0 and items[a - 1]["t"] == "term":
            a -= 1
        before = items[a - 1] if a > 0 else None
        if a == word or (before is not None and (before["t"] == "cond" or (
                before["t"] == "word" and before["shape"] in self.CONDITION_SHAPES))):
            return 0
        size = len(items)
        if quantity:
            items[word]["unit"] = items[k]["node"]
            del items[k]
        self._count_field(items, word)
        return size - len(items)

    @staticmethod
    def _group(items):
        nodes = [x["node"] for x in items]
        return nodes[0] if len(nodes) == 1 else {"kind": "phrase", "items": nodes}

    def _conditions_from(self, items, root_marks, i):
        """B (comparisons, negation, 몇+unit) from position i -> [(items, root_marks)]."""
        while i < len(items):
            word = items[i]
            if word["t"] != "word":
                i += 1
                continue
            shape = word["shape"]
            prev = items[i - 1] if i > 0 else None
            nxt = items[i + 1] if i + 1 < len(items) else None
            if shape == "compare_after":
                if word["category"] == "copula" and prev is not None and prev["t"] == "cond":
                    self._word_to_mark(items, i, root_marks)
                    continue
                if prev is not None and prev["t"] == "term":
                    # 039 규칙 14: 직원 수 10 안 넘는 → LE(field=COUNT(직원); 10).
                    at = self._count_field(items, i - 2)
                    if at is not None:
                        i = at + 2
                if prev is not None and prev["t"] == "term":
                    spans = self._compare_spans(items, i)
                    results = []
                    for field_lo, field_hi, value_lo in spans:
                        branch = deepcopy(items) if len(spans) > 1 else items
                        marks = deepcopy(root_marks) if len(spans) > 1 else root_marks
                        field = self._group(branch[field_lo:field_hi]) if field_hi > field_lo else None
                        cond = self._cond(branch[i], [self._group(branch[value_lo:i])], field)
                        branch[field_lo:i + 1] = [cond]
                        results.extend(self._conditions_from(branch, marks, field_lo + 1))
                        if len(results) > self.MAX_CANDIDATES:
                            raise PromiseLimit("CANDIDATES")
                    return results
                items[i] = self._cond(word, [], incomplete=True)
            elif shape in {"compare_before", "compare_between"}:
                at = self._count_field(items, i - 1)  # 039 규칙 14: 직원 수 >= 10
                if at is not None:
                    i, prev = at + 1, items[at]
                has_value = nxt is not None and nxt["t"] == "term"
                has_field = self._eligible_field(prev)
                cond = self._cond(word, [nxt["node"]] if has_value else [],
                                  prev["node"] if has_field else None, incomplete=not has_value)
                first = i - 1 if has_field else i
                last = i + 2 if has_value else i + 1
                items[first:last] = [cond]
                i = first + 1
                continue
            elif shape == "negate":
                if prev is not None and prev["t"] == "cond":
                    items[i - 1:i + 1] = [self._cond(word, [prev["node"]])]
                    continue
                if prev is not None and prev["t"] == "term":
                    before = items[i - 2] if i > 1 else None
                    has_field = self._eligible_field(before)
                    cond = self._cond(word, [prev["node"]], before["node"] if has_field else None)
                    first = i - 2 if has_field else i - 1
                    items[first:i + 1] = [cond]
                    i = first + 1
                    continue
                items[i] = self._cond(word, [], incomplete=True)
            elif shape == "absent":
                # 038 규칙 8: 없는 = NOT(EXISTS(앞 항목)). Only once the EXISTS operator
                # pack is registered; until then the word is a mark (no new operator).
                if "EXISTS" in self.operators and prev is not None and prev["t"] in {"term", "cond"}:
                    exists = self._op("EXISTS", [prev["node"]], [])
                    cond = self._cond(dict(word, op="NOT"), [exists])
                    items[i - 1:i + 1] = [cond]
                    continue
                self._word_to_mark(items, i, root_marks)
                continue
            elif shape == "quantity" and nxt is not None:
                if nxt["t"] == "term" and nxt["node"]["kind"] == "text":
                    word["unit"] = nxt["node"]
                    del items[i + 1]
                elif nxt["t"] == "word" and nxt["category"] == "generic_count_unit":
                    word["unit"] = {"kind": "word", **nxt["words"][0]}
                    self._add_marks(word, nxt.get("marks"))
                    del items[i + 1]
            i += 1
        return [(items, root_marks)]

    def _stage_field_values(self, items):
        """038 규칙 7 (좁힌 범위): a bare text piece and right after it a value written
        apart with nothing glued (no unit, no mark) that is the last item of the
        sentence (or before a comma/punctuation) -> EQ(field=piece, value)
        (사번 1234 누구야). Units (3명), dates (10월), ranks (1등) are glued to the
        number, so they never match; a value with anything after it is left alone."""
        i = 1
        while i < len(items):
            value, piece = items[i], items[i - 1]
            last = i + 1 == len(items) or items[i + 1]["t"] == "sep"
            if (last and value["t"] == "term" and value["node"]["kind"] == "value"
                    and not value["node"].get("marks") and value.get("spaced")
                    and piece["t"] == "term" and piece["node"]["kind"] == "text"
                    and not piece["node"].get("marks")):
                items[i - 1:i + 1] = [{"t": "cond", "node": self._op("EQ", [value["node"]], [],
                                                                      field=piece["node"])}]
                continue
            i += 1

    def _stage_clause_conditions(self, items):
        """038 규칙 1: [조각 이/가·은/는][표시 없는 조각…] 연결 [field 있는 조건] — the
        left clause is EQ(field, 값) too (근원 낱말 없음, words=[]), right to left so a
        chain of clauses is read whole. Stage C then joins the conditions."""
        i = len(items) - 2
        while i >= 1:
            word, right = items[i], items[i + 1]
            if (word["t"] == "word" and word["shape"] in {"or", "and"} and right["t"] == "cond"
                    and right["node"].get("field") is not None):
                j = i - 1
                while j >= 0 and self._bare(items[j]):
                    j -= 1
                if (j < i - 1 and j >= 0 and items[j]["t"] == "term" and items[j]["node"].get("marks")
                        and self._eligible_field(items[j])):
                    cond = {"t": "cond", "node": self._op("EQ", [self._group(items[j + 1:i])], [],
                                                          field=items[j]["node"])}
                    items[j:i] = [cond]
                    i = j - 1
                    continue
            i -= 1

    def _stage_condition_logic(self, items):
        """C: OR/AND with a condition on at least one side and a condition or a
        single text piece/value on the other (휴직이 아닌 그리고 여성). A join that
        stage A put off (right piece with 이/가·은/는) whose right side did not
        become a condition is made here like stage A (동결 전 수정: 휴직 또는 병가)."""
        chained = set()
        i = 1
        while i < len(items) - 1:
            word = items[i]
            sides = {items[i - 1]["t"], items[i + 1]["t"]}
            if (word["t"] == "word" and word["shape"] in {"or", "and"} and sides == {"term"}):
                left, right = items[i - 1]["node"], items[i + 1]["node"]
                if right.get("kind") == "op" and right.get("op") == word["op"] and "field" not in right:
                    # The right side is a stage-A chain of the same word: one list.
                    right["args"].insert(0, left)
                    right["words"][:0] = word["words"]
                    node = right
                elif left.get("kind") == "op" and left.get("op") == word["op"] and "field" not in left:
                    left["args"].append(right)
                    left["words"].extend(word["words"])
                    node = left
                else:
                    node = self._op(word["op"], [left, right], list(word["words"]))
                self._add_marks(node, word.get("marks"))
                items[i - 1:i + 2] = [{"t": "term", "node": node}]
                continue
            if (word["t"] == "word" and word["shape"] in {"or", "and"}
                    and "cond" in sides and sides <= {"cond", "term"}):
                left, right = items[i - 1]["node"], items[i + 1]["node"]
                if id(left) in chained and left["op"] == word["op"]:
                    left["args"].append(right)
                    left["words"].extend(word["words"])
                    node = left
                else:
                    node = self._op(word["op"], [left, right], list(word["words"]))
                    chained.add(id(node))
                self._add_marks(node, word.get("marks"))
                items[i - 1:i + 2] = [{"t": "cond", "node": node}]
                continue
            i += 1

    @staticmethod
    def _stage_filters(items):
        """D: neighbouring pieces -> phrase; conditions + following target -> FILTER."""
        i = 0
        while i < len(items):
            if items[i]["t"] == "term":
                j = i
                while j < len(items) and items[j]["t"] == "term":
                    j += 1
                if j - i > 1:
                    items[i:j] = [{"t": "phrase", "node": {"kind": "phrase",
                                                          "items": [x["node"] for x in items[i:j]]}}]
            i += 1
        i = 0
        while i < len(items):
            if items[i]["t"] != "cond":
                i += 1
                continue
            j = i
            while j < len(items) and items[j]["t"] == "cond":
                j += 1
            conds = [x["node"] for x in items[i:j]]
            if j < len(items) and items[j]["t"] in {"term", "phrase"}:
                node = {"kind": "op", "op": "FILTER", "words": [], "args": [items[j]["node"]] + conds}
                items[i:j + 1] = [{"t": "unit", "node": node}]
                continue
            prev = items[i - 1] if i > 0 else None
            if prev is not None and prev["t"] in {"term", "phrase"}:
                last = prev["node"]["items"][-1] if prev["t"] == "phrase" else prev["node"]
                if {m["role"] for m in last.get("marks", [])} & SCOPE_MARK_ROLES:
                    node = {"kind": "op", "op": "FILTER", "words": [], "args": [prev["node"]] + conds}
                    items[i - 1:j] = [{"t": "unit", "node": node}]
                    continue
            i = j

    def _stage_aggregates(self, items, start, request_moves):
        """E: aggregation takes the item on its left; none -> right; both -> two."""
        for i in range(start, len(items)):
            word = items[i]
            if word["t"] != "word" or word["shape"] not in {"aggregate", "quantity"}:
                continue
            is_unit = lambda x: x is not None and x["t"] in {"term", "phrase", "cond", "unit"}
            left = items[i - 1] if i > 0 else None
            right = items[i + 1] if i + 1 < len(items) else None
            left, right = (left if is_unit(left) else None), (right if is_unit(right) else None)
            if (word["category"] == "count_stem" and left is not None
                    and left["node"].get("kind") == "op" and left["node"].get("op") == "COUNT"):
                moved = list(items)
                moved[i] = {"t": "sep"}
                return self._stage_aggregates(moved, i + 1, request_moves + [word])

            def node(args, incomplete=False):
                extra = {"unit": word["unit"]} if "unit" in word else {}
                built = self._op(word["op"], args, word["words"], **extra)
                if incomplete:
                    built["incomplete"] = True
                self._add_marks(built, word.get("marks"))
                return {"t": "unit", "node": built}

            branches = []
            if left is not None:
                branches.append((items[:i - 1] + [node([left["node"]])] + items[i + 1:], i))
            if right is not None:
                branches.append((items[:i] + [node([right["node"]])] + items[i + 2:], i + 1))
            if not branches:
                branches.append((items[:i] + [node([], True)] + items[i + 1:], i + 1))
            results = []
            for branch, nxt in branches:
                results.extend(self._stage_aggregates(deepcopy(branch), nxt, request_moves))
                if len(results) > self.MAX_CANDIDATES:
                    raise PromiseLimit("CANDIDATES")
            return results
        return [(items, request_moves)]

    def _stage_arithmetic(self, items):
        """F: * / first, then + -, left to right; both sides must be items."""
        for shape in ("arith_mul", "arith_add"):
            i = 0
            while i < len(items):
                word = items[i]
                if word["t"] == "word" and word["shape"] == shape:
                    left = items[i - 1] if i > 0 else None
                    right = items[i + 1] if i + 1 < len(items) else None
                    # A condition is not a number: arithmetic takes pieces, phrases and results.
                    ok = all(x is not None and x["t"] in {"term", "phrase", "unit"} for x in (left, right))
                    if ok:
                        built = self._op(word["op"], [left["node"], right["node"]], word["words"])
                        self._add_marks(built, word.get("marks"))
                        items[i - 1:i + 2] = [{"t": "unit", "node": built}]
                        continue
                    built = self._op(word["op"], [], word["words"], incomplete=True)
                    self._add_marks(built, word.get("marks"))
                    items[i] = {"t": "unit", "node": built}
                i += 1

    def assemble(self, reading, confirm=frozenset()):
        """Formulas for one reading, in a fixed listing order (not a preference).
        038 — two places where the fixed rules allow two assemblies (약속서 3, the
        engine never picks): 규칙 2 a comma between two bare pieces may be a pause or
        a list; 규칙 3 a negation after 'A 또는 B이' may cover B or the whole list
        (옛 시험 A30·N26 '중의 — 확인 필요'). 042 규칙 26: 고 glued to a confirm word
        (confirm — the call's usable confirm words) or a value and followed by a condition
        may be 빼고's end (as before) or the short 이고 (AND). 048 규칙 35: a list word between two
        same-shape blocks (X E 와 Y E) may also list the blocks (OR([X E], [Y E])) — listed last.
        049 규칙 36: OR(X, Y) + common pieces + a pair_compare word (A와 B 매출 차이) may also be
        SUBTRACT([X 매출], [Y 매출]) — listed after those. The earlier assembly is listed first."""
        formulas = []
        commas = [False] + ([True] if any(self._list_comma(reading, i) for i in range(len(reading))) else [])
        for list_commas in commas:
            items = self._items(reading, list_commas)[0]
            scopes = [False] + ([True] if any(self._scope_point(items, i) for i in range(len(items))) else [])
            for negation_scope in scopes:
                formulas.extend(self._assemble(reading, list_commas, negation_scope))
                if len(formulas) > self.MAX_CANDIDATES:
                    raise PromiseLimit("CANDIDATES")
        go = self._go_points(reading, confirm)
        if go:
            formulas.extend(self._assemble(reading, False, False, go))
            if len(formulas) > self.MAX_CANDIDATES:
                raise PromiseLimit("CANDIDATES")
        # 048 규칙 35: same-shape list blocks (김성순 권역과 김종권 권역) — one more assembly per
        # comma reading, after all earlier ones; none when nothing has the same shape.
        for list_commas in commas:
            formulas.extend(self._assemble(reading, list_commas, same_shape=True))
            if len(formulas) > self.MAX_CANDIDATES:
                raise PromiseLimit("CANDIDATES")
        # 049 규칙 36: 'A와 B (칸) 차이' — SUBTRACT([A 칸], [B 칸]), after all earlier ones, on the first
        # assembly's list and on 규칙 35 blocks; none without a pair_compare word in that shape.
        if any(p["kind"] == "word" and PROMISE_SHAPES.get(p.get("category")) == "pair_compare" for p in reading):
            for list_commas in commas:
                for same_shape in (False, True):
                    formulas.extend(self._assemble(reading, list_commas, same_shape=same_shape, pair=True))
                    if len(formulas) > self.MAX_CANDIDATES:
                        raise PromiseLimit("CANDIDATES")
        return formulas

    @staticmethod
    def _eids(reading):
        return {(p["start"], p["end"]): p.get("expression_id") for p in reading if p["kind"] == "word"}

    def _go_points(self, reading, confirm):
        """042 규칙 26: spans of 고 (category exclude_end) glued right after a confirm word or a
        value (with its unit mark: 3만원고), that the first assembly leaves as a mark on a
        piece followed right away by a condition (퇴사고 휴직인 — 뒤에 이어 조건)."""
        points = set()
        for k, piece in enumerate(reading):
            if piece["kind"] != "word" or piece["category"] != EXCLUDE_END or k == 0:
                continue
            left = reading[k - 1]
            if left["end"] != piece["start"]:
                continue
            if (left["kind"] == "word" and left.get("category") == UNIT_MARK_ROLE and k >= 2
                    and reading[k - 2]["kind"] == "value" and reading[k - 2]["end"] == left["start"]):
                left = reading[k - 2]
            if left["kind"] == "value" or (left["kind"] == "text" and left["text"] in confirm):
                points.add((piece["start"], piece["end"]))
        if not points:
            return frozenset()
        items, _, root_marks = self._items(reading)
        self._stage_terms(items, root_marks, self._eids(reading))
        followed = set()
        for branch, _ in self._stage_conditions(items, root_marks):
            for k in range(len(branch) - 1):
                if branch[k]["t"] == "term" and branch[k + 1]["t"] == "cond":
                    followed.update((m["start"], m["end"]) for m in branch[k]["node"].get("marks", ())
                                    if (m["start"], m["end"]) in points)
        return frozenset(followed)

    def _assemble(self, reading, list_commas, negation_scope=False, and_go=frozenset(), same_shape=False,
                  pair=False):
        items, request, root_marks = self._items(reading, list_commas, and_go)
        joined = self._stage_terms(items, root_marks, self._eids(reading), negation_scope, same_shape)
        if same_shape and not joined:
            return []  # 048 규칙 35: nothing of the same shape -> no extra candidate
        if pair and not same_shape:
            # 049 (앞 조각 허용 뒤 겹침 막기): when 규칙 35 joins blocks in this reading, 규칙 36 stands only
            # on those blocks — not on the first assembly's 김성순 OR(권역, 김정훈) 권역.
            probe = self._items(reading, list_commas, and_go)[0]
            self._stage_list_marks(probe, self._eids(reading))
            if self._stage_same_shape(probe):
                return []
        if pair and not self._stage_pair_compare(items):
            return []  # 049 규칙 36: not the shape -> no extra candidate
        formulas = []
        for items, root_marks in self._stage_conditions(items, root_marks):
            self._stage_field_values(items)
            self._stage_clause_conditions(items)
            self._stage_condition_logic(items)
            self._stage_filters(items)
            self._stage_groups(items)
            formulas.extend(self._finish(items, request, root_marks))
            if len(formulas) > self.MAX_CANDIDATES:
                raise PromiseLimit("CANDIDATES")
        return formulas

    def _finish(self, items, request, root_marks):
        """E aggregation, F arithmetic and G leftovers for one condition reading."""
        formulas = []
        for branch, moved in self._stage_aggregates(items, 0, []):
            branch_marks = deepcopy(root_marks)
            self._stage_compares(branch)
            self._stage_arithmetic(branch)
            i = 0
            while i < len(branch):
                if branch[i]["t"] == "word":  # G: one-sided OR/AND (원칙5) -> mark
                    self._word_to_mark(branch, i, branch_marks)
                    continue
                i += 1
            branch_request = sorted(request + [_mark({"kind": "word", **w, "category": "count_stem"})
                                               for word in moved for w in word["words"]],
                                    key=lambda m: m["start"])
            formulas.append({"items": [x["node"] for x in branch if x["t"] != "sep"],
                             "request": branch_request, "marks": branch_marks})
        return formulas


def check_promise_formula(formula, text, operators):
    """Shape check of one promise formula; returns a list of problems."""
    problems, stack, seen = [], [(formula.get("items"), 0)], 0
    if set(formula) != {"items", "request", "marks"}:
        problems.append("ROOT_KEYS")

    def span(obj):
        return (isinstance(obj.get("start"), int) and isinstance(obj.get("end"), int)
                and 0 <= obj["start"] < obj["end"] <= len(text)
                and text[obj["start"]:obj["end"]] == obj.get("text"))

    for group in ("request", "marks"):
        for mark in formula.get(group, []):
            if not span(mark):
                problems.append("BAD_SPAN")
    while stack:
        nodes, depth = stack.pop()
        seen += 1
        if depth > 64 or seen > 4096 or not isinstance(nodes, list):
            problems.append("SHAPE_LIMIT")
            break
        for node in nodes:
            kind = node.get("kind")
            for mark in node.get("marks", []):
                if not span(mark):
                    problems.append("BAD_SPAN")
            if kind in {"text", "value"}:
                if not span(node):
                    problems.append("BAD_SPAN")
            elif kind == "phrase":
                stack.append((node.get("items"), depth + 1))
            elif kind == "op":
                if node.get("op") not in operators:
                    problems.append("UNKNOWN_OPERATOR")
                if any(not span(w) for w in node.get("words", [])):
                    problems.append("BAD_SPAN")
                extra = [x for x in (node.get("field"), node.get("unit")) if isinstance(x, dict)]
                if any(x.get("kind") == "word" and not span(x) for x in extra):
                    problems.append("BAD_SPAN")
                stack.append((list(node.get("args", [])) + [x for x in extra if x.get("kind") != "word"],
                              depth + 1))
            else:
                problems.append("UNKNOWN_NODE")
    return sorted(set(problems))
