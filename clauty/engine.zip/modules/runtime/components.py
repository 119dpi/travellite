# MASTER → modules/runtime/GUIDE.md → LOG.md 확인 후 수정. [ENG-RUNTIME-F05]
"""Declaration registry. No business data, expression learning or code loading."""
from copy import deepcopy


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be a nonempty string")


class Registry:
    """Independent declarations, not a table of question-to-formula mappings."""

    def __init__(self, data=(), operators=(), language=(), rules=()):
        self.data = self._index(data, "slot_id")
        self.operators = self._index(operators, "operator_id")
        self.language = self._index(language, "pack_id")
        self.rules = self._index(rules, "rule_id")
        expression_ids = set()
        for pack in self.language.values():
            if not isinstance(pack.get("status"), str) or pack["status"] not in {"draft", "active"}:
                raise ValueError("language status must be draft or active")
            if not isinstance(pack.get("entries"), list):
                raise ValueError("language entries must be a list")
            for entry in pack["entries"]:
                if not isinstance(entry, dict):
                    raise ValueError("expression must be an object")
                for key in ("expression_id", "text", "category"):
                    _text(entry.get(key), key)
                if entry["text"] != entry["text"].strip():
                    raise ValueError("expression cannot have surrounding whitespace")
                if entry["expression_id"] in expression_ids:
                    raise ValueError("duplicate expression_id")
                expression_ids.add(entry["expression_id"])
                attachment = entry.get("attachment", "free")
                if not isinstance(attachment, str) or attachment not in {"free", "suffix"}:
                    raise ValueError("attachment must be free or suffix")
                # ENGINE-RULES-038 규칙 11: a suffix the reader cuts only after a confirm word (or alone);
                # 042: "confirm_word" — only right after a confirm word, never alone.
                if "suffix_cut" in entry and (entry["suffix_cut"] not in {"after_confirm", "confirm_word"}
                                              or attachment != "suffix"):
                    raise ValueError("suffix_cut must be after_confirm or confirm_word on a suffix")
                # ENGINE-RULES-039 규칙 16: a free word read only from a chunk's first letter
                # (the whole chunk, or the word + end suffix words) — 퇴사이 stays 퇴사+이.
                if "whole_chunk" in entry and (entry["whole_chunk"] is not True or attachment != "free"):
                    raise ValueError("whole_chunk must be true on a free word")
                decomposition = entry.get("decomposition", "auto")
                if not isinstance(decomposition, str) or decomposition not in {"auto", "protected"}:
                    raise ValueError("decomposition must be auto or protected")
                if "canonical" in entry:
                    _text(entry["canonical"], "canonical")
                self._semantic(entry.get("semantic"))
                refs = entry.get("selection_rule_refs", [])
                if not isinstance(refs, list) or any(not isinstance(x, str) for x in refs):
                    raise ValueError("selection_rule_refs must be string IDs")
                if any(ref not in self.rules for ref in refs):
                    raise ValueError("unknown selection rule")
                kind = pack.get("target_kind")
                target = entry.get("target_ref")
                targets = {"data": self.data, "operator": self.operators, "relation": self.rules}
                if not isinstance(kind, str) or kind not in {"lexical", "data", "operator", "relation"}:
                    raise ValueError("unknown target_kind")
                if target is not None and not isinstance(target, str):
                    raise ValueError("target_ref must be a string or null")
                if kind in targets and target not in targets[kind]:
                    raise ValueError("unknown language target")
        for rule in self.rules.values():
            if not isinstance(rule.get("status"), str) or rule["status"] not in {"draft", "active"}:
                raise ValueError("rule status must be draft or active")
            kind = rule.get("rule_kind")
            if not isinstance(kind, str):
                raise ValueError("rule_kind must be a string")
            if kind == "attachment":
                for key in ("left_categories", "right_categories"):
                    values = rule.get(key)
                    if not isinstance(values, list) or not values:
                        raise ValueError("attachment needs category lists")
                    for value in values:
                        _text(value, key)
            elif kind == "value":
                if not isinstance(rule.get("matcher"), str) or rule["matcher"] not in {"digits", "decimal", "quoted"}:
                    raise ValueError("unsupported value matcher")
            elif kind == "compound":
                parts = rule.get("parts")
                if not isinstance(parts, list) or not 2 <= len(parts) <= 8:
                    raise ValueError("compound requires 2..8 ordered categories")
                for category in parts:
                    _text(category, "compound part")
                _text(rule.get("output_category"), "output_category")
                self._semantic(rule.get("semantic"))
            elif kind == "syntax":
                parts = rule.get("parts")
                if not isinstance(parts, list) or not 1 <= len(parts) <= 3:
                    raise ValueError("syntax requires 1..3 role categories")
                for category in parts:
                    _text(category, "syntax part")
                _text(rule.get("output_category"), "output_category")
                if not isinstance(rule.get("action"), str) or rule["action"] not in {
                    "pass", "bound_predicate", "values", "alternatives", "target",
                    "comparison_input", "compare", "equal", "negate",
                    "negate_operator", "logic", "restrict", "merge",
                    "aggregate_request", "aggregate", "measure",
                    "arithmetic_number", "arithmetic_query", "arithmetic_binary",
                    "range_start", "range_finish", "confirm_count_request",
                    "filter_field",
                }:
                    raise ValueError("unsupported syntax action")
                exact_parts = {"arithmetic_binary": 3, "range_finish": 2, "filter_field": 2}.get(rule["action"])
                if exact_parts is not None and len(parts) != exact_parts:
                    raise ValueError("syntax action has wrong operand count")
                if type(rule.get("select", 0)) is not int or not 0 <= rule.get("select", 0) < len(parts):
                    raise ValueError("invalid syntax select")
                if "operator_id" in rule and (not isinstance(rule["operator_id"], str)
                                              or rule["operator_id"] not in self.operators):
                    raise ValueError("unknown syntax operator")
                if (not isinstance(rule.get("literal_policy", "preserve"), str)
                        or rule.get("literal_policy", "preserve") not in {"preserve", "field_type"}):
                    raise ValueError("unknown literal policy")
                if rule["action"] == "range_finish":
                    if (rule.get("operator_id"), rule.get("lower_operator_id"),
                            rule.get("upper_operator_id")) != ("AND", "GE", "LE"):
                        raise ValueError("range requires explicit inclusive operators")
                    if any(rule[key] not in self.operators for key in
                           ("operator_id", "lower_operator_id", "upper_operator_id")):
                        raise ValueError("unknown range operator")
                if rule["action"] in {"bound_predicate", "equal", "negate", "logic",
                                      "restrict", "merge", "aggregate_request"} and "operator_id" not in rule:
                    raise ValueError("syntax action needs explicit operator")
            elif kind not in {"relation", "selection", "composition"}:
                raise ValueError("unknown rule_kind")

    def _semantic(self, semantic):
        if semantic is None:
            return
        if not isinstance(semantic, dict) or not isinstance(semantic.get("kind"), str) or semantic["kind"] not in {
            "entity", "field", "operator", "aggregation", "literal", "bound_value", "unit", "marker"
        }:
            raise ValueError("invalid semantic terminal")
        kind = semantic["kind"]
        if kind in {"entity", "field"} and (not isinstance(semantic.get("slot_id"), str)
                                            or semantic["slot_id"] not in self.data):
            raise ValueError("unknown semantic slot")
        if kind in {"operator", "aggregation"} and (not isinstance(semantic.get("operator_id"), str)
                                                   or semantic["operator_id"] not in self.operators):
            raise ValueError("unknown semantic operator")
        if kind == "bound_value" and (not isinstance(semantic.get("field_ref"), str)
                                      or semantic["field_ref"] not in self.data):
            raise ValueError("unknown bound field")
        if kind == "unit" and (not isinstance(semantic.get("entity_ref"), str)
                               or semantic["entity_ref"] not in self.data):
            raise ValueError("unknown unit entity")
        if "negated" in semantic and type(semantic["negated"]) is not bool:
            raise ValueError("negated must be boolean")
        if kind in {"literal", "bound_value"}:
            dtype, value = semantic.get("value_type"), semantic.get("value")
            if not ((dtype == "string" and isinstance(value, str))
                    or (dtype == "integer" and type(value) is int)
                    or (dtype == "boolean" and type(value) is bool)):
                raise ValueError("invalid semantic literal")

    @staticmethod
    def _index(entries, key):
        if not isinstance(entries, (list, tuple)):
            raise ValueError("declarations must be a list")
        result = {}
        for entry in entries:
            if not isinstance(entry, dict):
                raise ValueError("declaration must be an object")
            _text(entry.get(key), key)
            if entry[key] in result:
                raise ValueError("duplicate " + key)
            result[entry[key]] = deepcopy(entry)
        return result

    def expressions(self):
        return [dict(deepcopy(entry), pack_id=pack["pack_id"])
                for pack in self.language.values() if pack["status"] == "active"
                for entry in pack["entries"]]

    def active_rules(self, kind):
        return [deepcopy(rule) for rule in self.rules.values()
                if rule["status"] == "active" and rule["rule_kind"] == kind]


def load_korean_registry(root, *, features=(), disabled=()):
    """Engine packs only (ENGINE-CLEANUP-035 — no host names, slots or values; 약속서 4)."""
    from .pack_loader import load_pack_declarations
    declarations = load_pack_declarations(root, features=features, disabled=disabled)
    return Registry((), declarations["operators"], declarations["language_packs"], declarations["rules"])
