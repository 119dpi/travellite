# MASTER → modules/runtime/GUIDE.md → LOG.md 확인 후 수정. [ENG-RUNTIME-F12]
"""Owner-addressed declarations. No business data, callbacks, guessing or disk cache."""
import json
from pathlib import Path, PurePosixPath
import re

FEATURES = ("symbols", "arithmetic", "connectives", "composition")
KINDS = ("operators", "language_packs", "rules")

def _names(items, allowed, label):
    if (not isinstance(items, (list, tuple)) or any(not isinstance(x,str) for x in items)
            or len(items)!=len(set(items)) or set(items)-set(allowed)):
        raise ValueError("unknown or duplicate " + label)
    return tuple(items)

def _path(root, name):
    if not isinstance(name,str) or not name or "\\" in name:
        raise ValueError("invalid pack path")
    relative=PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts or relative.as_posix()!=name:
        raise ValueError("non-local pack path: " + name)
    path=root/name
    if not path.resolve().is_relative_to(root):
        raise ValueError("pack path escapes root")
    for part in (path,*path.parents):
        if part==root:break
        if part.is_symlink():raise ValueError("pack symlinks are not supported")
    return path

def _read(root,name):
    obj=json.loads(_path(root,name).read_text(encoding="utf-8"))
    if not isinstance(obj,dict) or type(obj.get("schema_version")) is not int or obj["schema_version"]!=1:
        raise ValueError("invalid pack schema: " + name)
    return obj

def _manifest(root):
    manifest=_read(root,"packs/manifest.json")
    modules=manifest.get("modules")
    if manifest.get("features")!=list(FEATURES) or not isinstance(modules,list) or not modules:
        raise ValueError("invalid pack manifest")
    owners={}
    paths=set()
    for module in modules:
        if not isinstance(module,dict):raise ValueError("invalid pack module")
        owner=module.get("owner")
        if not isinstance(owner,str) or not re.fullmatch(r"(operator\.[A-Z][A-Z_0-9]*|language\.[a-z_]+|rule\.[a-z_]+)",owner):
            raise ValueError("invalid pack owner")
        if owner in owners:raise ValueError("duplicate pack owner")
        kind,name=owner.split(".")
        prefix={"operator":"packs/operators/","language":"packs/language/","rule":"packs/rules/"}[kind]+name+"/"
        files=module.get("files")
        if not isinstance(files,dict) or not files or set(files)-set(KINDS):
            raise ValueError("invalid owner files")
        expected={"operator":set(KINDS),"language":{"language_packs"},"rule":{"rules"}}[kind]
        if set(files)!=expected:
            raise ValueError("incomplete owner boundary")
        for key,path in files.items():
            leaf={"operators":"definition.json","language_packs":"language.json","rules":"rules.json"}[key]
            if path!=prefix+leaf or path in paths:
                raise ValueError("wrong owner path or duplicate file")
            _path(root,path)
            paths.add(path)
        _names(module.get("features"),("base",)+FEATURES,"module features")
        if not module["features"]:
            raise ValueError("owner needs an explicit feature")
        deps=module.get("dependencies")
        if not isinstance(deps,dict) or set(deps)!=set(module["features"]):
            raise ValueError("invalid owner dependencies")
        for key in ("provides_categories","uses_categories"):
            if not isinstance(module.get(key),list) or any(not isinstance(x,str) or not x for x in module[key]):
                raise ValueError("invalid category edges")
        owners[owner]=module
    for module in modules:
        for deps in module["dependencies"].values():
            _names(deps,owners,"pack dependency")
    return owners

def _active(owners,features,disabled):
    selected={"base",*features}
    active={k:v for k,v in owners.items() if k not in disabled and set(v["features"])&selected}
    edges={}
    for owner,module in active.items():
        deps=set(d for f,ds in module["dependencies"].items() if f in selected for d in ds)
        missing=deps-set(active)
        if missing:raise ValueError("missing pack dependency for "+owner+": "+",".join(sorted(missing)))
        edges[owner]=deps
    visiting,done=set(),set()
    def walk(owner):
        if owner in visiting:raise ValueError("cyclic pack dependency")
        if owner in done:return
        visiting.add(owner)
        for dep in edges[owner]:walk(dep)
        visiting.remove(owner);done.add(owner)
    for owner in edges:walk(owner)
    return active

def load_pack_declarations(root, *, features=(), disabled=()):
    """Select explicit owners; disabled dependents must also be removed deliberately."""
    root=Path(root).resolve()
    features=_names(features,FEATURES,"Korean pack feature")
    owners=_manifest(root)
    disabled=_names(disabled,owners,"disabled pack owner")
    active=_active(owners,features,disabled)
    selected=("base",)+features
    rows={k:[] for k in KINDS}
    orders={k:set() for k in KINDS}
    for owner,module in active.items():
        for kind,path in module["files"].items():
            bundle=_read(root,path)
            if bundle.get("owner")!=owner or not isinstance(bundle.get("entries"),list):
                raise ValueError("owner mismatch or invalid entries: "+path)
            for row in bundle["entries"]:
                if not isinstance(row,dict) or row.get("feature") not in module["features"]:
                    raise ValueError("invalid declaration feature: "+path)
                feature,order,value=row["feature"],row.get("order"),row.get("value")
                if (type(order) not in (int,float) or not 0 <= order <= 1000000000 or not isinstance(value,dict)):
                    raise ValueError("invalid declaration row: "+path)
                if feature not in selected:continue
                order_key=(feature,order)
                if order_key in orders[kind]:raise ValueError("duplicate declaration order")
                orders[kind].add(order_key)
                if kind=="operators" and owner!="operator."+str(value.get("operator_id")):
                    raise ValueError("operator ownership mismatch")
                if kind=="language_packs" and value.get("target_kind")=="operator":
                    if owner!="operator."+str(value.get("owner_ref")) or any(
                        e.get("target_ref")!=value["owner_ref"] for e in value.get("entries",[])):
                        raise ValueError("language operator ownership mismatch")
                refs=[]
                if kind=="rules":
                    if value.get("operator_id"):refs.append(value["operator_id"])
                    for key in ("lower_operator_id", "upper_operator_id"):
                        if value.get(key):refs.append(value[key])
                    if value.get("semantic",{}).get("operator_id"):refs.append(value["semantic"]["operator_id"])
                for ref in refs:
                    target="operator."+ref
                    if target not in active:raise ValueError("unavailable rule operator: "+target)
                    if target!=owner and target not in module["dependencies"][feature]:
                        raise ValueError("undeclared operator dependency: "+target)
                rows[kind].append((selected.index(feature),order,value))
    declarations={kind:[r[2] for r in sorted(items,key=lambda x:(x[0],x[1]))] for kind,items in rows.items()}
    expected_operators={o.split(".",1)[1] for o in active if o.startswith("operator.")}
    if {o.get("operator_id") for o in declarations["operators"]}!=expected_operators:
        raise ValueError("active operator owner lacks its declaration")
    return declarations

def pack_impact(root, owner, *, features=()):
    """Hard dependents block removal; category consumers are potential interactions."""
    root=Path(root).resolve()
    features=_names(features,FEATURES,"Korean pack feature")
    owners=_manifest(root)
    if owner not in owners:raise ValueError("unknown pack owner")
    active=_active(owners,features,())
    selected={"base",*features}
    affected={owner}
    while True:
        linked={k for k,v in active.items() if any(
            affected.intersection(ds) for f,ds in v["dependencies"].items() if f in selected)}
        new=affected|linked
        if new==affected:break
        affected=new
    categories=set(owners[owner]["provides_categories"])
    consumers=sorted(k for k,v in active.items() if k!=owner and categories.intersection(v["uses_categories"]))
    return {"owner":owner,"files":dict(owners[owner]["files"]),
            "required_by":sorted(affected-{owner}),"category_consumers":consumers,
            "category_edges_are_potential_not_proof":True}


# ENGINE-RULES-044 A (사용자 10/26 "언어팩 구조만 잘 잡혀 있다면 베어본으로 주고 거기서 그 프로젝트용으로 또 채우면"):
# 프로젝트 팩 층 — root/projects/<host_id>/language.json 하나만(그 호스트 것만, 다른 프로젝트 폴더는
# 절대 읽지 않음). 파일이 없거나 비면 아무것도 더하지 않는다(= 공통 팩만의 출력 그대로).
PROJECT_DIR = "projects"
PROJECT_FILE = "language.json"
PROJECT_HOST = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}")
PROJECT_SEMANTICS = ("marker", "operator", "aggregation")  # 명사 금지: entity·field·literal·unit 등은 못 씀

def load_project_pack(root, host_id, common_expressions):
    """{"packs": [...], "entries": n, "warnings": [...]} for this host's project pack.
    Packs are lexical language packs using the common packs' categories. A word with the same
    letters (folded) as a common word and another category is refused (ValueError — 한 낱말 = 한 뜻);
    the same category is a warning. host_id not usable as a folder name -> no project pack."""
    empty={"packs":[],"entries":0,"warnings":[]}
    if not isinstance(host_id,str) or not PROJECT_HOST.fullmatch(host_id):
        return empty
    from .tokenizer import fold_text
    root=Path(root).resolve()
    name=PROJECT_DIR+"/"+host_id+"/"+PROJECT_FILE
    if not _path(root,name).is_file():
        return empty
    bundle=_read(root,name)
    if bundle.get("host_id")!=host_id or not isinstance(bundle.get("packs"),list):
        raise ValueError("project pack host mismatch or invalid packs: "+name)
    common={}
    for e in common_expressions:
        common.setdefault(fold_text(e["text"]),set()).add(e["category"])
    categories={c for cats in common.values() for c in cats}
    mine,warnings,count={},[],0
    prefix="project."+host_id+"."
    for pack in bundle["packs"]:
        if not isinstance(pack,dict) or not str(pack.get("pack_id","")).startswith(prefix):
            raise ValueError("project pack_id must start with "+prefix)
        if pack.get("target_kind")!="lexical" or not isinstance(pack.get("entries"),list):
            raise ValueError("project pack must be lexical with entries")
        for e in pack["entries"]:
            if not isinstance(e,dict) or not str(e.get("expression_id","")).startswith(prefix):
                raise ValueError("project expression_id must start with "+prefix)
            if not isinstance(e.get("text"),str) or not isinstance(e.get("category"),str):
                raise ValueError("project word needs text and category")
            if e["category"] not in categories:
                raise ValueError("project word uses a category no common pack has: "+e["category"])
            if e.get("target_ref") is not None:
                raise ValueError("project word cannot target data or operators")
            semantic=e.get("semantic")
            if semantic is not None and (not isinstance(semantic,dict) or semantic.get("kind") not in PROJECT_SEMANTICS):
                raise ValueError("project word semantic must be marker/operator/aggregation (no names)")
            key=fold_text(e["text"])
            if key in common and e["category"] not in common[key]:
                raise ValueError("project word overlaps a common word with another category: "+e["text"])
            if key in common:
                warnings.append("duplicate of a common word (same category): "+e["text"])
            if key in mine and mine[key]!=e["category"]:
                raise ValueError("project word has two categories: "+e["text"])
            mine[key]=e["category"]
            count+=1
    return {"packs":[dict(p) for p in bundle["packs"]],"entries":count,"warnings":warnings}
