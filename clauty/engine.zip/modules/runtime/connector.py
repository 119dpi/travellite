# MASTER → modules/runtime/GUIDE.md → LOG.md 확인 후 수정. [ENG-RUNTIME-F13]
"""Clauty promise compile port (CONTRACT 약속서). No DB, executor, network, or model calls.

ENGINE-CLEANUP-035: the connector takes no host names, slots or values. It reads
the sentence once with the engine packs (one profile), turns registered words
into fixed operators, keeps every other character as an original text piece with
its position, and returns every assembly the fixed rules allow. Choosing among
candidates, finding text pieces in Clauty's dictionary and fetching values are
Clauty's part.

ENGINE-PACK-037: a compile call may carry confirm_words (확인 팩 — exact strings the
host already knows). The reader only checks "is this text in the set"; matching
text stays one original text piece. The output format does not change, and an
empty or missing set reads exactly as before.
"""
import hashlib
import json

from .assembler import PROMISE_SCHEMA, PROMISE_SHAPES, PromiseAssembler, check_promise_formula
from .components import Registry, load_korean_registry
from .pack_loader import FEATURES, load_project_pack
from .tokenizer import (COUNT_UNITS, COUNTER_UNITS, CURRENCY_UNITS, DATE_UNITS, PERCENT_UNITS,
                        TIME_UNITS, PromiseLimit, PromiseReader)


PROTOCOL_VERSION = 1
MAX_JSON_CHARS = 65536
ENGINE_CONTRACT = "promise-1"
MAX_CONFIRM_WORDS = 65536
MAX_CONFIRM_WORD_CHARS = 128
READING_POLICY = {"version": 8,
                  "rule": "spaced_chunk_unit_whole_cover_or_end_suffix_rest_original_text",
                  "number_units": "digits_then_baek_cheon_man_eok",
                  # ENGINE-RULES-038: 규칙 10 큰→작은 단위 더하기, 규칙 6 숫자 바로 뒤 단위 표시,
                  # 규칙 5 띄어 쓴 등록 낱말(덩어리 그대로), 규칙 11 확인 낱말 뒤에서만 떼는 끝 조사.
                  "number_groups": "bigger_to_smaller_units_added_in_one_chunk",
                  "count_units": sorted(COUNT_UNITS),
                  "spaced_words": "whole_chunks_in_a_row",
                  "suffix_cut": "after_confirm",
                  # ENGINE-RULES-039: 규칙 12·13 숫자 바로 뒤 %·개도 단위 표시, 범주 number_unit
                  # 낱말(퍼센트·프로 — GPT Work)은 숫자 바로 뒤에서만, 규칙 16 whole_chunk 낱말.
                  "percent_units": sorted(PERCENT_UNITS),
                  "counter_units": sorted(COUNTER_UNITS),
                  "unit_words": "number_unit_category_only_right_after_a_number",
                  "whole_chunk": "free_word_only_from_chunk_start",
                  # ENGINE-RULES-040: 규칙 17 띄어 쓴 백천만억(+ 그 뒤 띄어 쓴 단위 표시), 규칙 19 몇 바로
                  # 뒤 단위 글자(덩어리 전체가 덮일 때만), 규칙 20 전각 숫자 ０~９(값 글자만 0~9).
                  "spaced_number_units": "digits_chunk_then_baek_cheon_man_eok_chunk_and_unit_mark_chunk",
                  "quantity_units": "count_units_right_after_quantity_word_whole_cover",
                  "wide_digits": "fullwidth_0_to_9_value_ascii_text_kept",
                  # 040 규칙 21(지휘관 추가): 1,000 쉼표 숫자·1.5 소수 = 값 하나(소수는 matcher decimal).
                  "comma_decimal_numbers": "comma_groups_of_three_and_one_point_decimal_one_value",
                  # ENGINE-RULES-042: 규칙 22 숫자 바로 뒤 날짜 단위(긴 것 먼저, 붙여 쓴 날짜는 다음 숫자까지),
                  # after_confirm 끝 조사 뒤 붙임표 짝 끝 조사(순으로).
                  "date_units": list(DATE_UNITS),
                  # ENGINE-RULES-044: 규칙 27 통화 단위(3만엔 = 30000), 규칙 28 시간 단위(날짜 단위 다음).
                  "currency_units": list(CURRENCY_UNITS),
                  "time_units": list(TIME_UNITS),
                  "suffix_cut_tail": "after_confirm_then_paired_end_suffixes",
                  "confirm_words": "exact_text_whole_chunk_or_less_end_suffix_and_cover",
                  "max_readings": 1,
                  "max_pieces": PromiseReader.MAX_PIECES}


def _identifier(value):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= 128


def _strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError("nonfinite JSON constant")


class EngineConnector:
    """Engine packs only; compile requests cannot add names, rules or context."""

    def __init__(self, root, *, host_id, revision):
        if not _identifier(host_id) or not _identifier(revision):
            raise ValueError("host_id/revision need nonempty strings up to 128 characters")
        # One profile: every engine pack, no host declarations (약속서 4).
        registry = load_korean_registry(root, features=FEATURES)
        # ENGINE-RULES-044 A: this host's project pack only (projects/<host_id>/language.json) — absent or
        # empty adds nothing (same output and same declaration hash as the common packs alone).
        project = load_project_pack(root, host_id, registry.expressions())
        self._project = None
        if project["packs"]:
            registry = Registry((), list(registry.operators.values()),
                                list(registry.language.values()) + project["packs"], list(registry.rules.values()))
            self._project = {"host_id": host_id, "entries": project["entries"],
                             "warnings": project["warnings"]}
        # E5 end words (사용자 10/23 "2번도 진행해"): the shape table's request
        # categories and the negation category — no word list here.
        self._reader = PromiseReader(registry, end_categories={
            c for c, shape in PROMISE_SHAPES.items() if shape == "request"} | {"negation"})
        self._assembler = PromiseAssembler(registry)
        self._operators = frozenset(registry.operators)
        self._host_id, self._revision = host_id, revision
        declarations = {"operators": registry.operators, "language": registry.language,
                        "rules": registry.rules}
        if self._project:
            declarations["project"] = project["packs"]
        encoded = json.dumps(declarations, sort_keys=True, ensure_ascii=True, allow_nan=False)
        self._fingerprint = hashlib.sha256(encoded.encode("ascii")).hexdigest()

    @classmethod
    def from_host(cls, root, *, host_id, revision):
        """Trusted setup only. The host gives its identity, never names or slots."""
        return cls(root, host_id=host_id, revision=revision)

    def confirm_set(self, confirm_words):
        """(usable, conflicts) — conflicts are confirm words a registered word,
        value or boundary wins over (보고용). ValueError on a bad set."""
        if confirm_words is None:
            return frozenset(), []
        if isinstance(confirm_words, (str, bytes, dict)) or not hasattr(confirm_words, "__iter__"):
            raise ValueError("confirm_words must be a collection of strings")
        words = list(confirm_words)
        if len(words) > MAX_CONFIRM_WORDS or any(
                not isinstance(w, str) or not w or len(w) > MAX_CONFIRM_WORD_CHARS for w in words):
            raise ValueError("confirm_words: up to 65536 nonempty strings of up to 128 characters")
        return self._reader.confirm_set(words)

    def compile_text(self, text, confirm_words=None):
        """(status, result) for one sentence: compiled or limited.
        confirm_words (선택, ENGINE-PACK-037 A): exact strings from the host."""
        confirm = self.confirm_set(confirm_words)[0]
        try:
            readings = self._reader.read(text, confirm)
            candidates, keys = [], set()
            for reading in readings:
                for formula in self._assembler.assemble(reading, confirm):
                    key = json.dumps(formula, ensure_ascii=False, sort_keys=True)
                    if key in keys:
                        continue
                    keys.add(key)
                    candidates.append({"formula": formula, "reading": reading})
                    if len(candidates) > PromiseAssembler.MAX_CANDIDATES:
                        raise PromiseLimit("CANDIDATES")
        except PromiseLimit as limit:
            return "limited", {"schema": PROMISE_SCHEMA, "text": text, "candidates": None,
                               "limit": str(limit)}
        for candidate in candidates:
            if check_promise_formula(candidate["formula"], text, self._operators):
                raise ValueError("invalid promise formula")
        return "compiled", {"schema": PROMISE_SCHEMA, "text": text, "candidates": candidates}

    def _response(self, status, code, request_id=None, result=None):
        return {"protocol_version": PROTOCOL_VERSION, "request_id": request_id,
                "host_id": self._host_id, "host_revision": self._revision,
                "declaration_sha256": self._fingerprint,
                "status": status, "code": code, "execution_enabled": False,
                "result": result}

    def handle(self, request):
        if not isinstance(request, dict):
            return self._response("invalid_request", "INVALID_REQUEST")
        ident = request.get("request_id")
        if ident is not None and not _identifier(ident):
            return self._response("invalid_request", "INVALID_REQUEST_ID")
        version = request.get("protocol_version")
        if type(version) is not int or version != PROTOCOL_VERSION:
            return self._response("invalid_request", "PROTOCOL_VERSION_MISMATCH", ident)
        action = request.get("action")
        if not isinstance(action, str) or action not in {"capabilities", "compile"}:
            return self._response("invalid_request", "INVALID_ACTION", ident)
        allowed = {"protocol_version", "request_id", "action"}
        if action == "compile":
            allowed |= {"text", "host_revision", "confirm_words"}
        if set(request) - allowed:
            return self._response("invalid_request", "UNKNOWN_REQUEST_FIELDS", ident)
        if action == "capabilities":
            return self._response("ready", "CONNECTOR_CAPABILITIES", ident, {
                "actions": ["capabilities", "compile"], "max_text_chars": 4096,
                "max_json_chars": MAX_JSON_CHARS, "engine_contract": ENGINE_CONTRACT,
                "formula_schema": PROMISE_SCHEMA,
                "max_candidates": PromiseAssembler.MAX_CANDIDATES,
                "reading_policy": dict(READING_POLICY),
                "host_declarations": False,
                "local_connector_ready": True, "live_integration_verified": False,
                "declared_operators": len(self._operators),
                "authorization": "host_required", "execution": "host_only",
                "automatic_split": False, "continuation_supported": False,
                "confirm_words": {"max_words": MAX_CONFIRM_WORDS,
                                  "max_word_chars": MAX_CONFIRM_WORD_CHARS},
                **({"project_pack": dict(self._project)} if self._project else {})})
        if request.get("host_revision") != self._revision:
            return self._response("invalid_request", "HOST_REVISION_MISMATCH", ident)
        text = request.get("text")
        if not isinstance(text, str) or not text.strip() or len(text) > 4096:
            return self._response("invalid_request", "INVALID_TEXT", ident)
        confirm_words = request.get("confirm_words")
        if "confirm_words" in request:
            if not isinstance(confirm_words, list):
                return self._response("invalid_request", "INVALID_CONFIRM_WORDS", ident)
            try:
                self.confirm_set(confirm_words)
            except ValueError:
                return self._response("invalid_request", "INVALID_CONFIRM_WORDS", ident)
        try:
            status, result = self.compile_text(text, confirm_words)
            if status == "compiled":
                return self._response("compiled", "FORMULA_COMPILED", ident, result)
            return self._response("needs_input", "ASSEMBLY_LIMITED", ident, result)
        except Exception:
            # Explicit failure, never a fake count=0 or a partially usable plan.
            # The host may log/monitor this code; exception details are not exported.
            return self._response("internal_error", "ENGINE_INTERNAL_ERROR", ident)

    def handle_json(self, payload):
        """One JSON value in/out for a future host-owned MCP/stdio/HTTP wrapper."""
        try:
            if not isinstance(payload, str) or len(payload) > MAX_JSON_CHARS:
                raise ValueError("invalid payload size/type")
            request = json.loads(payload, object_pairs_hook=_strict_object,
                                 parse_constant=_invalid_constant)
        except (ValueError, RecursionError):
            response = self._response("invalid_request", "INVALID_JSON")
        else:
            response = self.handle(request)
        return json.dumps(response, ensure_ascii=True, allow_nan=False)
