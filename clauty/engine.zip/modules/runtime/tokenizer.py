# MASTER → modules/runtime/GUIDE.md → LOG.md 확인 후 수정. [ENG-RUNTIME-F06]
"""Clauty promise reading (ENGINE-CLEANUP-035): dictionary-driven, no inference."""
from collections import defaultdict
import json
import re
import unicodedata


PUNCTUATION = frozenset("?!,;:()[]{}。！？、，")  # 038 규칙 2: 、·， 도 쉼표
VALUE_MATCHERS = {
    "digits": re.compile(r"[0-9]+"),
    "decimal": re.compile(r"[+-]?[0-9]+\.[0-9]+"),
    "quoted": re.compile(r'"(?:\\.|[^"\\])*"'),
}
# ENGINE-PACK-037 B (사용자 10/23, 수첩 설계 B): 백·천·만·억(과 그 겹침 천만·백억 …)
# written right after a whole number are part of that number (3만 -> 30000).
NUMBER_UNITS = {"백": 100, "천": 1000, "만": 10 ** 4, "억": 10 ** 8}
NUMBER_UNIT = re.compile(r"[백천]?[만억]|[백천]")
# ENGINE-RULES-040 규칙 20: 전각 숫자 ０~９도 숫자 — 원문 글자·위치는 그대로, 값 글자만 0~9로.
# 다른 숫자 모양(①·² 등)은 넣지 않는다(NFKC 접기 전체가 아니라 이 열 글자만).
WIDE_DIGITS = {0xFF10 + i: 0x30 + i for i in range(10)}
DIGIT_CHARS = frozenset("0123456789") | frozenset(chr(0xFF10 + i) for i in range(10))
DIGITS = re.compile(r"[0-9０-９]+")
# ENGINE-RULES-040 규칙 21 (지휘관 10/24 — 틀린 값 최우선): 띄어쓰기 없이 숫자 + (쉼표 + 숫자 정확히
# 3자리)가 한 번 이상 = 값 하나(1,000 -> 1000), 숫자.숫자 = 값 하나(1.5). 점 둘 이상(날짜·버전),
# 3자리 아닌 묶음(1,00·1,0000), 앞에 글자·숫자·쉼표·점이 붙은 꼴은 값 하나로 만들지 않는다(전과 같음).
COMMA_NUMBER = re.compile(r"[0-9０-９]+(?:,[0-9０-９]{3})+(?![0-9０-９]|,[0-9０-９])")
DECIMAL_NUMBER = re.compile(r"[0-9０-９]+\.[0-9０-９]+(?![0-9０-９]|\.[0-9０-９])")
# ENGINE-RULES-038 규칙 6 (구조 상수 — GPT Work 확인): 숫자(+백천만억) 바로 뒤에 붙을 때만
# 단위로 떼는 글자. 일반 끝 조사로 등록하지 않으므로 직원·사원·증명은 안 잘린다. 개는 등록
# COUNT 낱말(generic_count_unit)이라 등록 낱말이 이긴다 — 표에 넣지 않음.
COUNT_UNITS = frozenset({"원", "명", "건", "곳"})
# ENGINE-RULES-039 규칙 12·13 (구조 상수 — GPT Work 확인): 숫자 바로 뒤 %(접기로 ％도)와 '개'도
# 같은 단위 조각(number_unit). '개'는 등록 COUNT 낱말이지만 숫자 바로 뒤 자리에서는 단위 —
# 숫자 없는 '몇 개'·'개수'는 그대로 COUNT. 퍼센트·프로는 낱말(범주 number_unit, GPT Work)로
# 들어오며, 범주 number_unit 낱말은 숫자 바로 뒤에서만 읽는다(일반 끝 조사로 떼지 않음).
PERCENT_UNITS = frozenset({"%"})
COUNTER_UNITS = frozenset({"개"})
UNIT_MARKS = COUNT_UNITS | PERCENT_UNITS | COUNTER_UNITS
UNIT_CATEGORY = "number_unit"
# ENGINE-RULES-042 규칙 22 (구조 상수 — GPT Work 확인): 숫자 바로 뒤 날짜 단위 글자도 같은 단위
# 조각(number_unit, 값은 숫자 그대로 — 3월 -> #3{월}). 긴 것 먼저(년도 > 년 — 년도를 년 + 도로 자르지
# 않음). 날짜 계산(이번 달이 며칠부터인지·분기 기준)은 클로티 몫. 붙여 쓴 날짜(2026년3월)는 단위
# 뒤가 다음 숫자로 이어져도 된다. 숫자 없는 월요일·년도·분기별은 그대로(등록 낱말 아님).
# ENGINE-RULES-044 규칙 29 (구조 상수 — GPT Work 확인): 일차(3일차)는 일보다 먼저 — 일 + 차로 자르지 않음.
DATE_UNITS = ("년도", "분기", "일차", "월", "년", "일", "주")
# ENGINE-RULES-044 규칙 27 (구조 상수 — 목록은 GPT Work 확인): 숫자(+백천만억) 바로 뒤 통화 단위 글자도
# 같은 단위 조각(number_unit) — 3만엔 = #30000{엔}, 3 만 엔(규칙 17), 1,500엔, 2.5만엔. 긴 것 먼저.
# '원'은 COUNT_UNITS 그대로. 숫자 없는 엔진·유로파는 그대로(등록 낱말 아님).
CURRENCY_UNITS = ("달러", "위안", "유로", "바트", "엔")
# ENGINE-RULES-044 규칙 28 (구조 상수 — GPT Work 확인): 숫자 바로 뒤 시간 단위. 긴 것 먼저(시간 > 시),
# DATE_UNITS가 먼저(3분기 = 분기). 붙여 쓴 꼴(3시30분·1박2일)은 다음 숫자에서 끊음(날짜 단위와 같음).
TIME_UNITS = ("시간", "시", "분", "초", "박")
# ENGINE-RULES-047 규칙 34 (구조 상수 — 글자 목록은 GPT Work 확인): 시간 단위 시·시간(HALF_AFTER) 바로 뒤의 반은
# 같은 값의 단위 표시 조각(number_unit) — 붙여 쓴 3시반·1시간반, 띄어 쓴 '반' 홀로 덩어리 또는 '반'+등록 끝 조사
# 덩어리(3시 반에). 값은 바꾸지 않는다(3시 반 = 값 3 + 표시 [시, 반] — 30분으로 읽는 것은 호스트). 시·시간
# 단위 바로 뒤가 아니면(반값·반 친구·3반·반만) 전과 같다.
HALF_UNITS = ("반",)
HALF_AFTER = frozenset({"시간", "시"})
# ENGINE-RULES-040 규칙 19: 숫자 자리 낱말(범주 quantity — 몇) 바로 뒤에 붙은 COUNT_UNITS 글자는
# 띄어 쓴 '몇 명'과 같은 읽기(몇 + 원문 조각 명) — 몇명·몇곳. 덩어리 전체가 덮일 때만(E2①).
QUANTITY_CATEGORY = "quantity"
# ENGINE-RULES-040 (지휘관 10/24 "3만~5만 틀린 값은 지금 고칠 것"): 038 범위 구조 글자 ~(접기로 ～도)는
# 숫자 단위 꼬리의 경계 — 기호 낱말처럼 그 앞에서 꼬리를 끊는다(3만~5만 = #30000 ~ #50000).
RANGE_TILDE = "~"
# ENGINE-RULES-038 규칙 11: 낱말 항목의 선택 키 suffix_cut = "after_confirm" — 그 끝 조사는
# 덩어리 = 확인 낱말 + 그 조사일 때와 조사 홀로(띄어 쓴 덩어리·값 바로 뒤)일 때만 읽는다.
AFTER_CONFIRM = "after_confirm"
# ENGINE-RULES-042 (지휘관 10/25): suffix_cut = "confirm_word" — 확인 낱말 바로 뒤에서만(홀로·값 뒤는 아님).
# 별: 권역별·권역별로(확인 낱말 권역)는 읽고, 홀로 선 별로(매출이 별로 없는)는 읽지 않는다.
CONFIRM_WORD = "confirm_word"
# ENGINE-RULES-046 규칙 32 (구조 상수): 범주 request_end의 1글자 끝(라)은 덮이지 않는 덩어리 끝에서 E2(b) 일반
# suffix로 떼지 않는다 — 기요미즈데라·신데렐라·콜라·카메라·나라는 원문 조각 하나. 등록 낱말이 덩어리를 빈틈없이
# 덮으면(보여라·해라) 덮개 쪽이라 그대로, 2글자 이상 끝(세요)과 E5 요청 끝 묶음(하늘보여라)도 그대로.
REQUEST_END_CATEGORY = "request_end"
# ENGINE-RULES-049 (지휘관 설계 — 칸 이름 보호 ①): 범주 pair_compare(뒤붙이 비교 쌍 낱말 — 차이, 낱말은 GPT Work)와
# 같은 글자의 확인 낱말은 충돌로 빼지 않고 확인 낱말이 이긴다(그 글자는 원문 조각 — 규칙 36을 쓰지 않음).
# 다른 범주 등록 낱말과 같은 글자면 전처럼 등록 낱말이 이긴다(4-5 ③).
PAIR_COMPARE_CATEGORY = "pair_compare"


def _unit_mark(text, start, end):
    """A unit-mark piece that is no registered word (038 규칙 6 꼴 — role number_unit)."""
    return {"kind": "word", "text": text[start:end], "start": start, "end": end, "category": UNIT_CATEGORY,
            "attachment": "suffix", "expression_id": None, "semantic": None}


def _number_token(text, pos, end=None):
    """040 규칙 21: end of the comma number (1,000) or decimal (1.5) starting at pos, or None."""
    if pos > 0 and (text[pos - 1].isalnum() or text[pos - 1] in ".,"):
        return None
    end = len(text) if end is None else end
    match = COMMA_NUMBER.match(text, pos, end) or DECIMAL_NUMBER.match(text, pos, end)
    return match.end() if match else None


def _scaled(raw):
    """040 규칙 21 (정밀도 수정 — 호출자 Decimal context와 무관한 정확한 정수 연산): the value
    text 1,000 / 1.5 as (integer, decimal places) — 1.5 -> (15, 1), meaning 15 / 10**1."""
    whole, _, places = raw.replace(",", "").partition(".")
    return int(whole + places), len(places)


def _number_text(number, places):
    """(integer, decimal places) as value text: a whole number without a point, else the
    plain decimal with no trailing zeros — glyphs built directly, never rounded."""
    whole, rest = divmod(number, 10 ** places)
    if not rest:
        return str(whole)
    return f"{whole}." + str(rest).rjust(places, "0").rstrip("0")


def _chunks(text, symbols=()):
    """Keep original character offsets; punctuation is not silently discarded."""
    # 040 규칙 21: the commas of a comma number (1,000) stay inside its chunk.
    number_commas = set()
    for match in COMMA_NUMBER.finditer(text):
        if _number_token(text, match.start()) == match.end():
            number_commas.update(i for i in range(match.start(), match.end()) if text[i] == ",")

    def punctuation_at(index):
        return (text[index] in PUNCTUATION and index not in number_commas
                and not any(text.startswith(s, index) for s in symbols))

    pos = 0
    while pos < len(text):
        if text[pos].isspace():
            pos += 1
            continue
        start = pos
        quoted = VALUE_MATCHERS["quoted"].match(text, pos)
        if quoted:
            pos = quoted.end()
            yield text[start:pos], start, pos, "word"
            continue
        if punctuation_at(pos) or text[pos] == ".":
            pos += 1
            yield text[start:pos], start, pos, "punctuation"
            continue
        while pos < len(text) and not text[pos].isspace() and not punctuation_at(pos):
            # A quoted value next to a registered symbol stays opaque, even
            # when it contains punctuation such as the ! in name="a!b".
            quoted = VALUE_MATCHERS["quoted"].match(text, pos) if symbols else None
            if quoted:
                pos = quoted.end()
                continue
            if text[pos] == "." and not (
                    pos > start and pos + 1 < len(text)
                    and text[pos - 1] in DIGIT_CHARS and text[pos + 1] in DIGIT_CHARS):
                break
            pos += 1
        yield text[start:pos], start, pos, "word"


def fold_char(c):
    """One character -> one character (NFKC, then lower case). A character whose
    form would change length stays as written, so every original position is
    preserved. Used only for comparing registered words (ENGINE-CLEANUP-035:
    the first step of the promise reading, not a retry)."""
    n = unicodedata.normalize("NFKC", c)
    if len(n) != 1:
        return c
    low = n.lower()
    return low if len(low) == 1 else n


def fold_text(text):
    return "".join(fold_char(c) for c in text)


class PromiseLimit(Exception):
    """The promise reading would exceed its declared bounds; no partial output."""


class PromiseReader:
    """ENGINE-CLEANUP-035: the one reading of the Clauty promise (CONTRACT 약속서).

    Only engine pack words and value matchers are known; every other character
    stays as an original text piece with its position. The reader never decides
    whether a text piece is a person, store, field or value, and never cuts a
    chunk apart (동결 해제 2026-10-23, E1~E4 — 사용자 "봇은 봇이다").

    1. Registered words are compared after fold_char on both sides (same length,
       original positions and surfaces kept). Values match the original text.
    2. E1: the unit is a chunk written apart (whitespace/punctuation). Quoted
       values and registered symbol words (+ >= …) are always boundaries; digits
       are values (E3).
    3. E2: a chunk becomes registered words only (a) when the whole chunk is
       covered by registered words and values, or (b) for suffix words at a run's
       end, taken from the end, longest first; two suffix words in a row need a
       registered attachment pair; a suffix needs something to its left. All the
       rest of a run is one original text piece (E4: a suffix inside is not cut).
    4. E3: digits (and '-digits') written right after a letter belong to the text
       piece (파트너1·SEED1·파트너1-2) unless the whole chunk is covered (a).
    5. E5 (사용자 10/23 "2번도 진행해"): when the run is not covered, its end
       covered only by end_categories words (request/ending and negation — given
       by the host of this reader from the fixed shape table), taken from the end
       longest first, is cut when it is 2+ characters and letters stay before it;
       rule 3(b) then applies to what stays before it.
    6. ENGINE-PACK-037 A — confirm words (확인 팩, given per call by the host): the
       reader only checks "is this exact text in the set" and never learns what a
       word is. A chunk equal to a confirm word, or equal to one after cutting one
       registered suffix word at its end, is one original text piece (+ that
       suffix). Confirm words also join the E2(a) cover (김성순권역 -> 김성순 +
       권역) and come out as original text pieces. A confirm word whose folded text
       is a registered word, that is all digits, or that holds whitespace,
       punctuation, a quote or a registered symbol word is not used (the
       registered word / value / boundary wins) — see confirm_set. ENGINE-RULES-049:
       a pair_compare word (차이) is the exception — the confirm word wins. An empty set
       reads exactly as without it.
    7. ENGINE-PACK-037 B — number units: 백·천·만·억 (and 천만·백억 …) right after a
       whole number (not digits after '.'/',' that are no 040 rule-21 number: 1,00·2026.10) belong to that
       value — 3만 -> value "30000", text "3만" — only when the rest of the chunk
       (up to a symbol word) is empty or wholly registered suffix/operator words
       (3만 이상·3만이상·1억이상인: yes; 3만큼·3백화점·5천원: no, read as before).
       '만' after anything else stays the registered limiter suffix (가나점만).
    8. ENGINE-RULES-040: rule 17 — a digits-only chunk and a next chunk starting with
       백·천·만·억 read as written together (3 만 이상 -> #30000), and after a 백·천·만·억
       unit a unit-mark chunk is its unit (1 억 원 / 1억 원) — _spaced_number. Rule 19 —
       원·명·건·곳 right after a quantity word (몇명 = 몇 명) inside a wholly covered chunk.
       Rule 20 — fullwidth digits ０~９ are digits (value text 0~9, original text kept).
    9. ENGINE-RULES-046: rule 31 - request/ending words cut from the end of an uncovered run never stand in for
       a protected whole_chunk word that 039 rule 16 refused here (the chunk 하늘보여줄래 stays one piece;
       보여+줄래 only when registered words cover the whole chunk) - see _run/_ends. Rule 32 - a 1-letter
       request_end suffix (라) is not cut by E2(b) from an uncovered run (기요미즈데라, 콜라 = one piece);
       registered cover (보여라) and E5 end groups (하늘보여라) are unchanged.
    One reading per sentence. Bound: 256 pieces.
    """

    MAX_PIECES = 256

    def __init__(self, registry, end_categories=frozenset()):
        everything = registry.expressions()
        # 039 규칙 12: number_unit words (퍼센트·프로) are read only right after a number.
        self.unit_words = {fold_text(e["text"]): e for e in everything
                           if e["category"] == UNIT_CATEGORY and not any(c.isspace() for c in e["text"])}
        everything = [e for e in everything if e["category"] != UNIT_CATEGORY]
        self.expressions = [e for e in everything if not any(c.isspace() for c in e["text"])]
        # 038 규칙 5 자리: a registered word written with spaces (안 되는) is read only as
        # exactly those whole chunks in a row — never inside a chunk (none registered yet).
        self.spaced = {tuple(fold_text(p) for p in e["text"].split()): e
                       for e in everything if any(c.isspace() for c in e["text"])}
        self.spaced_max = max((len(k) for k in self.spaced), default=0)
        self.symbols = tuple({e["text"] for e in self.expressions
                              if e.get("decomposition") == "protected"
                              and all(not c.isalnum() and not c.isspace()
                                      and c not in {'"', "'"} for c in e["text"])})
        self.lexicon = defaultdict(list)
        for entry in self.expressions:
            self.lexicon[fold_text(entry["text"])].append(entry)
        self.max_len = max((len(k) for k in self.lexicon), default=0)
        self.end_categories = frozenset(end_categories)
        self.symbol_keys = sorted({fold_text(s) for s in self.symbols}, key=len, reverse=True)
        self.pairs = frozenset((left, right) for rule in registry.active_rules("attachment")
                               for left in rule["left_categories"] for right in rule["right_categories"])
        self.matchers = [rule["matcher"] for rule in registry.active_rules("value")
                         if rule["matcher"] in {"digits", "quoted"}]

    def confirm_set(self, words):
        """(usable, conflicts) for the host's confirm words. Exact text, no folding.
        conflicts: words the registered words, values or boundaries win over."""
        usable, conflicts = set(), []
        for word in words or ():
            if not isinstance(word, str) or not word:
                raise ValueError("confirm words must be nonempty strings")
            registered = [e for e in self.lexicon.get(fold_text(word), ())
                          if e["category"] != PAIR_COMPARE_CATEGORY]  # 049: 확인 낱말이 이김
            if (registered or word.isdigit()
                    or any(c.isspace() or c in PUNCTUATION or c in "\"'" for c in word)
                    or any(s in word for s in self.symbols)):
                conflicts.append(word)
            else:
                usable.add(word)
        return frozenset(usable), sorted(set(conflicts))

    @staticmethod
    def _word(entry, start, end, text):
        return {"kind": "word", "text": text[start:end], "start": start, "end": end,
                "category": entry["category"], "attachment": entry.get("attachment", "free"),
                "expression_id": entry["expression_id"], "semantic": entry.get("semantic")}

    def _rejected_wholes(self, folded, lo, hi, chunk_start):
        """046 규칙 31: spans of whole_chunk words found in folded[lo:hi] that 039 규칙 16 does not let
        be read here (not the chunk's first letter) — 하늘보여줄래 holds 보여줄래."""
        return [(i, i + size) for i in range(lo, hi)
                for size in range(1, min(self.max_len, hi - i) + 1)
                for entry in self.lexicon.get(folded[i:i + size], ())
                if entry.get("whole_chunk") and not (chunk_start and i == lo)]

    def _trailing(self, folded, lo, hi, text, categories=None, confirm=frozenset(), chunk_start=False, guard=()):
        """Words at the end of folded[lo:hi], longest first, right to left
        (only words of the given categories when categories is set). Confirm words
        (exact original text) take part only when confirm is given; at one size a
        registered word comes first. They come out as original text pieces.
        039 규칙 16: a whole_chunk word only when lo is the chunk's first letter
        (chunk_start) and the word starts there.
        046 규칙 31: guard = spans of whole_chunk words that were not allowed here; a shorter word
        of the request/ending categories (end_categories) wholly inside such a span is not taken
        (보여+줄래 never stands in for 보여줄래; 퇴사이 keeps its 이 — 이 is no request word)."""
        stack, end = [], hi
        longest = max([self.max_len] + [len(w) for w in confirm])
        while end > lo:
            chosen = None
            for size in range(min(longest, end - lo), 0, -1):
                for entry in self.lexicon.get(folded[end - size:end], ()):
                    if categories is not None and entry["category"] not in categories:
                        continue
                    if entry["category"] == PAIR_COMPARE_CATEGORY and text[end - size:end] in confirm:
                        continue  # 049: 같은 글자의 확인 낱말이 pair_compare 낱말을 이긴다(원문 조각)
                    cut = entry.get("suffix_cut")
                    if cut in (AFTER_CONFIRM, CONFIRM_WORD) and not (
                            (text[lo:end - size] in confirm or (cut == AFTER_CONFIRM and end - size == lo))
                            and all(w.get("attachment") == "suffix" for w in stack)):
                        # 038 규칙 11: only alone, or after a confirm word; 042: either may be
                        # followed by end suffix words (each pair registered — 순으로, 매출순으로);
                        # confirm_word only after a confirm word (권역별로, never 별로 alone).
                        continue
                    if entry.get("whole_chunk") and not (chunk_start and end - size == lo):
                        continue  # 039 규칙 16: 사이 only as the chunk (+ end suffix), never 퇴사이
                    if entry["category"] in self.end_categories and any(
                            a <= end - size and end <= b and (end - size, end) != (a, b) for a, b in guard):
                        continue  # 046 규칙 31: a request/ending part of a protected whole_chunk word
                    right = stack[0] if stack else None
                    if (right is not None and right.get("attachment") == "suffix"
                            and entry.get("attachment", "free") == "suffix"
                            and (entry["category"], right["category"]) not in self.pairs):
                        continue
                    chosen = (entry, size)
                    break
                if not chosen and text[end - size:end] in confirm:
                    chosen = (None, size)
                if chosen:
                    break
            if (not chosen and categories is None and end - 1 > lo and folded[end - 1] in COUNT_UNITS
                    and self._quantity_ends_at(folded, lo, end - 1)):
                chosen = (None, 1)  # 040 규칙 19: 몇명 = 몇 + 명 (띄어 쓴 '몇 명'과 같은 읽기)
            if not chosen:
                break
            entry, size = chosen
            stack.insert(0, self._word(entry, end - size, end, text) if entry else
                         {"kind": "text", "text": text[end - size:end], "start": end - size, "end": end})
            end -= size
        return stack

    def _quantity_ends_at(self, folded, lo, end):
        """040 규칙 19: a registered quantity word (몇) ends at end, inside folded[lo:end]."""
        return any(e["category"] == QUANTITY_CATEGORY
                   for size in range(1, min(self.max_len, end - lo) + 1)
                   for e in self.lexicon.get(folded[end - size:end], ()))

    def _covering(self, text, folded, lo, hi, left_in_chunk, left_any, confirm=frozenset()):
        trailing = self._trailing(folded, lo, hi, text, confirm=confirm, chunk_start=not left_in_chunk)
        # Whole run read as words: the first word must be able to stand first. A
        # suffix may start a run right after a value in the chunk, or after a
        # space only when the whole run is suffix words (직원 이 / 직원 이나).
        while (trailing and trailing[0]["start"] == lo and trailing[0].get("attachment") == "suffix"
               and not left_in_chunk
               and (not left_any or any(w.get("attachment") != "suffix" for w in trailing))):
            trailing.pop(0)
        return trailing

    def _run(self, text, folded, lo, hi, left_in_chunk, left_any, confirm=frozenset()):
        """(pieces, covered) for one run of letters between boundaries."""
        if confirm:
            # A: the E2(a) cover with confirm words; otherwise exactly as without them.
            cover = self._covering(text, folded, lo, hi, left_in_chunk, left_any, confirm)
            if cover and cover[0]["start"] == lo:
                return cover, True
        trailing = self._covering(text, folded, lo, hi, left_in_chunk, left_any)
        if trailing and trailing[0]["start"] == lo:
            return trailing, True
        # E5: request/ending or negation words wholly covering 2+ end characters.
        pieces = self._ends(text, folded, lo, hi, left_in_chunk, trailing, ())
        if len(pieces) > 1:
            # 046 규칙 31: cut words must not stand in for a protected whole_chunk word (보여+줄래 for 보여줄래 in
            # 하늘보여줄래, 띄워+줄래 for 띄워줄래): when they end where such a word ends and the rest of it is
            # empty or a protected whole_chunk word itself, read again without request/ending words inside it.
            head, spans = pieces[0]["end"], self._rejected_wholes(folded, lo, hi, not left_in_chunk)
            ends = {w["end"] for w in pieces[1:]}
            if any(b in ends and (a == head or (a, head) in spans) for a, b in spans):
                pieces = self._ends(text, folded, lo, hi, left_in_chunk, trailing, spans)
        return pieces, False

    def _ends(self, text, folded, lo, hi, left_in_chunk, trailing, guard):
        """E5 then E2(b) for a run that is not covered: the text piece plus the cut end words."""
        end_words = self._trailing(folded, lo, hi, text, self.end_categories, guard=guard)
        if end_words and hi - end_words[0]["start"] >= 2 and end_words[0]["start"] > lo:
            hi = end_words[0]["start"]
            trailing = self._trailing(folded, lo, hi, text, guard=guard)
        else:
            end_words = []
            if guard:
                trailing = self._trailing(folded, lo, hi, text, chunk_start=not left_in_chunk, guard=guard)
        # E2(b): only the suffix words at the end are cut; the rest is one piece.
        cut = len(trailing)
        while (cut and trailing[cut - 1].get("attachment") == "suffix" and trailing[cut - 1]["start"] > lo
               and not (trailing[cut - 1]["category"] == REQUEST_END_CATEGORY  # 046 규칙 32
                        and trailing[cut - 1]["end"] - trailing[cut - 1]["start"] == 1)):
            cut -= 1
        tail = trailing[cut:]
        b = tail[0]["start"] if tail else hi
        return [{"kind": "text", "text": text[lo:b], "start": lo, "end": b}] + tail + end_words

    def _symbol_at(self, folded, pos, end):
        return next((len(k) for k in self.symbol_keys if folded.startswith(k, pos)
                     and pos + len(k) <= end), 0)

    def _split(self, text, folded, start, end, left_any, matches, glued, confirm=frozenset()):
        """(pieces, covered): values and symbol words split the chunk into runs."""
        pieces, covered, mark, pos, after_edge = [], True, start, start, False
        values = {m[0]: m for m in matches}

        def flush(stop):
            nonlocal covered, after_edge
            if mark < stop:
                run, whole = self._run(text, folded, mark, stop, after_edge, left_any or mark > start,
                                       confirm)
                pieces.extend(run)
                covered = covered and whole
                after_edge = False

        while pos < end:
            if pos in values:
                flush(pos)
                pos, value, extra = values[pos][1], values[pos][2], values[pos][3]
                pieces.append(value)
                pieces.extend(extra)
                mark, after_edge = pos, True
                continue
            stop = pos
            while not any(a <= stop < b for a, b in glued) and self._symbol_at(folded, stop, end):
                stop += self._symbol_at(folded, stop, end)
            if stop > pos:
                # A run of symbol words is cut from its end, longest first (>== -> > ==).
                flush(pos)
                pieces.extend(self._trailing(folded, pos, stop, text))
                pos = mark = stop
                after_edge = True
                continue
            pos += 1
        flush(end)
        return pieces, covered

    def _confirmed(self, text, folded, start, end, confirm):
        """A: the chunk, or the chunk less one registered suffix word at its end
        (longest first), is a confirm word -> that one text piece (+ the suffix)."""
        if text[start:end] in confirm:
            return [{"kind": "text", "text": text[start:end], "start": start, "end": end}]
        for size in range(min(self.max_len, end - start - 1), 0, -1):
            cut = end - size
            if text[start:cut] not in confirm:
                continue
            for entry in self.lexicon.get(folded[cut:end], ()):
                if entry.get("attachment", "free") == "suffix":
                    return [{"kind": "text", "text": text[start:cut], "start": start, "end": cut},
                            self._word(entry, cut, end, text)]
        return None

    def _chunk(self, text, folded, start, end, left_any, confirm=frozenset()):
        """One chunk. E3: digits written right after a letter (with '-digits'
        following: 파트너1-2) stay in the text piece, unless the chunk read with
        them as values is wholly covered by registered words and values (E2a)."""
        if confirm:
            pieces = self._confirmed(text, folded, start, end, confirm)
            if pieces:
                return pieces
        matches = self._values(text, start, end, folded)
        pieces, covered = self._split(text, folded, start, end, left_any, matches, (), confirm)
        if covered:
            return pieces
        glued, kept, index = [], [], 0
        while index < len(matches):
            pos, stop, part, _extra = matches[index]
            if part["matcher"] == "digits" and pos > start and text[pos - 1].isalpha():
                while (index + 1 < len(matches) and matches[index + 1][2]["matcher"] == "digits"
                       and matches[index + 1][0] == stop + 1 and text[stop] == "-"):
                    index += 1
                    stop = matches[index][1]
                glued.append((pos, stop))
            else:
                kept.append(matches[index])
            index += 1
        if not glued:
            return pieces
        return self._split(text, folded, start, end, left_any, kept, glued, confirm)[0]

    def _unit_tail_ok(self, text, folded, lo, end, date=False):
        """B: the rest after number+unit, up to the chunk end or the first symbol
        word (or range ~, 040; or, after a date unit, the next digit — 042 2026년3월),
        is empty or wholly covered by registered suffix or operator words."""
        hi = min([end] + [i for i in range(lo, end)
                          if folded[i] == RANGE_TILDE or self._symbol_at(folded, i, end)
                          or (date and text[i] in DIGIT_CHARS)])
        if lo == hi:
            return True
        words = self._trailing(folded, lo, hi, text)
        return bool(words) and words[0]["start"] == lo and all(
            w.get("attachment") == "suffix" or (w.get("semantic") or {}).get("kind") == "operator"
            for w in words)

    def _values(self, text, start, end, folded=None):
        """(start, end, value piece) for every value in the chunk."""
        folded = fold_text(text) if folded is None else folded
        found, pos = [], start
        while pos < end:
            match = None
            if text[pos] == '"' and "quoted" in self.matchers:
                match = VALUE_MATCHERS["quoted"].match(text, pos, end)
                if match:
                    try:
                        value = json.loads(match.group())
                    except (ValueError, TypeError):
                        match = None
                    else:
                        matcher = "quoted"
            stop = match.end() if match else None
            extra = []
            if match is None and "digits" in self.matchers and text[pos] in DIGIT_CHARS:
                match = DIGITS.match(text, pos, end)
                # 040 규칙 21: a comma number (1,000) or a decimal (1.5) is one value.
                stop = _number_token(text, pos, end) or match.end()
                value = text[pos:stop].translate(WIDE_DIGITS).replace(",", "")
                # B·038: units right after a number (not after '.'/',' left over: 1,00·2026.10.24).
                if not self._after_decimal_mark(text, pos):
                    number = self._number(text, folded, pos, stop, end)
                    if number:
                        value, stop, extra = number
                matcher = "decimal" if "." in value else "digits"
            if match is None:
                pos += 1
                continue
            after = extra[-1]["end"] if extra else stop  # 039: a unit word may be longer than 1
            found.append((pos, after, {"kind": "value", "matcher": matcher, "value": value,
                                                   "text": text[pos:stop], "start": pos, "end": stop}, extra))
            pos = after
        return found

    @staticmethod
    def _after_decimal_mark(text, pos):
        """The digits at pos follow '.'/',' after a digit — left over when no 040 rule-21
        number formed (the 00 of 1,00, the 10 of 2026.10.24)."""
        return pos >= 2 and text[pos - 1] in ".," and text[pos - 2] in DIGIT_CHARS

    def _number(self, text, folded, pos, stop, end, unit_at=None, mark_at=None):
        """(value, value end, [unit piece]) or None. B: 백·천·만·억 after the digits.
        038 규칙 10: in one chunk, groups from a bigger to a smaller unit are added
        (1억5천만 = 150000000, 1만5000 = 15000) — a group is added only while its value
        is below the unit before it. 038 규칙 6: a COUNT_UNITS letter right after the
        number is a unit piece (role number_unit). All only when what follows, up to the
        chunk end or a symbol word, is nothing or registered suffix/operator words.
        040 규칙 17 (_spaced_number): unit_at = where the 백·천·만·억 chunk written apart
        starts (it must be there); mark_at = (number end, start of the unit-mark chunk
        written apart) — the mark must be there, after a 백·천·만·억 unit."""
        q, total = (stop if unit_at is None else unit_at), None
        unit = NUMBER_UNIT.match(text, q, end)
        if unit_at is not None and not unit:
            return None
        if unit:
            size = 1
            for c in unit.group():
                size *= NUMBER_UNITS[c]
            total, places = _scaled(text[pos:stop].translate(WIDE_DIGITS))
            total, q = total * size, unit.end()
            while True:
                digits = DIGITS.match(text, q, end)
                if not digits:
                    break
                more = NUMBER_UNIT.match(text, digits.end(), end)
                step = 1
                for c in (more.group() if more else ""):
                    step *= NUMBER_UNITS[c]
                part = int(digits.group()) * step
                if part >= size:
                    break
                total, q, size = total + part * 10 ** places, (more.end() if more else digits.end()), step
                if not more:
                    break
        value = (text[pos:stop].translate(WIDE_DIGITS).replace(",", "") if total is None
                 else _number_text(total, places))  # 040 규칙 21: 1.5만 -> 15000, 0.5천 -> 500
        m = q
        if mark_at is not None:
            if total is None or q != mark_at[0]:
                return None
            m = mark_at[1]
        # 039 규칙 12: a registered number_unit word (퍼센트·프로, GPT Work) right after the
        # number, longest first, then the structure letters (원·명·건·곳, %, 개).
        for size in range(min(max((len(k) for k in self.unit_words), default=0), end - m), 0, -1):
            entry = self.unit_words.get(folded[m:m + size])
            if entry and self._unit_tail_ok(text, folded, m + size, end):
                return value, q, [dict(self._word(entry, m, m + size, text), category=UNIT_CATEGORY,
                                       attachment="suffix")]
        mark = lambda size: [{"kind": "word", "text": text[m:m + size], "start": m, "end": m + size,
                              "category": UNIT_CATEGORY, "attachment": "suffix",
                              "expression_id": None, "semantic": None}]
        if m < end and folded[m] in UNIT_MARKS and self._unit_tail_ok(text, folded, m + 1, end):
            return value, q, mark(1)
        # 044 규칙 27: currency units (엔·달러 …) also after a 백·천·만·억 unit written apart (3 만 엔).
        for unit in CURRENCY_UNITS:
            if (folded.startswith(unit, m, end) and not self._longer_word_at(folded, m, end, len(unit))
                    and self._unit_tail_ok(text, folded, m + len(unit), end)):
                return value, q, mark(len(unit))
        # 042 규칙 22 · 044 규칙 28·29: date and time units only glued right after the number
        # (not 1 억 월 written apart). Date units first (3분기 = 분기, 3일차 = 일차).
        for unit in (DATE_UNITS + TIME_UNITS if mark_at is None else ()):
            # 044: a time unit never cuts into a longer registered word (3초과 stays 초과, 3시작 stays 시작).
            if not folded.startswith(unit, m, end) or (
                    unit in TIME_UNITS and self._longer_word_at(folded, m, end, len(unit))):
                continue
            if self._unit_tail_ok(text, folded, m + len(unit), end, date=True):
                return value, q, mark(len(unit))
            # 047 규칙 34: 3시반·1시간반 — 반 glued right after 시·시간 is that value's unit mark too.
            half = m + len(unit)
            if unit in HALF_AFTER:
                for word in HALF_UNITS:
                    if (folded.startswith(word, half, end)
                            and self._unit_tail_ok(text, folded, half + len(word), end, date=True)):
                        return value, q, mark(len(unit)) + [_unit_mark(text, half, half + len(word))]
        if mark_at is None and total is not None and self._unit_tail_ok(text, folded, q, end):
            return value, q, []
        return None

    def _longer_word_at(self, folded, m, end, size):
        """044: a registered word starts at m and is longer than the unit (size)."""
        return any(folded[m:m + n] in self.lexicon and m + n <= end
                   for n in range(size + 1, self.max_len + 1))

    def _spaced_number(self, text, folded, chunks, k, left_any, confirm, at=None):
        """040 규칙 17 (최우선 — 틀린 값 막기, 띄어쓰기 실수 허용): (pieces, last chunk index)
        or None. A chunk of digits only, and right after it (whitespace only between) a
        chunk starting with 백·천·만·억 whose rest is what B allows after a unit (nothing,
        a unit mark, registered suffix/operator words) -> one value, as if written
        together: 3 만 이상 -> #30000 + 이상, 10 만 -> #100000. After a 백·천·만·억 unit
        (written apart or together: 1 억, 1억), a next chunk that is a unit mark (원·명·
        건·곳·%·개, number_unit word) + what B allows is that value's unit: 1 억 원 이상 /
        1억 원 이상 -> #100000000{원} + 이상. Not: 3 만큼·3 백화점 (rest not allowed),
        만 원 (no number), 3 명 (no 백·천·만·억 — 038, 전과 같음), a chunk that is a confirm
        word, digits left after '.'/',' (1,00·2026.10.24). 040 규칙 21: 1,000 만·1.5 만 join too."""
        if "digits" not in self.matchers or k + 1 >= len(chunks):
            return None
        _, first, end, kind = chunks[k]
        if kind != "word":
            return None
        # The number starts the chunk, or follows a registered symbol word or the range ~
        # (always a boundary — 매출>=3 만 is 매출 >= 3 만, 3만~5 만 is 3만 ~ 5 만); never
        # letters+digits (E3: 목표가500 만). at: the start given by a range chained before.
        starts = [at] if at is not None else [
            p for p in range(first, end) if text[p] in DIGIT_CHARS and (p == first or (
                text[p - 1] not in DIGIT_CHARS and (folded[p - 1] == RANGE_TILDE or any(
                    folded.endswith(s, first, p) for s in self.symbol_keys))))]
        if not starts or self._after_decimal_mark(text, starts[-1]):
            return None
        start = starts[-1]
        number_end = _number_token(text, start, end) or DIGITS.match(text, start, end).end()  # 040 규칙 21

        def joined(index, prev_end):
            if index >= len(chunks):
                return None
            _, s, e, kind_ = chunks[index]
            if kind_ != "word" or not text[prev_end:s].isspace():
                return None
            if confirm and self._confirmed(text, folded, s, e, confirm):
                return None
            return s, e

        tries, nxt = [], joined(k + 1, end)
        if nxt is None:
            return None
        if number_end == end and NUMBER_UNIT.match(text, nxt[0], nxt[1]):
            mark = joined(k + 2, nxt[1])
            if mark:
                tries.append((mark[1], k + 2, nxt[0], (nxt[1], mark[0])))
            tries.append((nxt[1], k + 1, nxt[0], None))
        elif number_end < end:
            tries.append((nxt[1], k + 1, None, (end, nxt[0])))
        for stop, last, unit_at, mark_at in tries:
            number = self._number(text, folded, start, number_end, stop, unit_at, mark_at)
            if number is None:
                continue
            value, q, extra = number
            after = extra[-1]["end"] if extra else q
            piece = {"kind": "value", "matcher": "decimal" if "." in value else "digits", "value": value,
                     "text": text[start:q], "start": start, "end": q}
            head = self._chunk(text, folded, first, start, left_any, confirm) if start > first and at is None else []
            # 3 만~5 만: the joined chunk ends in ~ + digits, and those digits join the next
            # chunk in the same way (the second number of a range written apart).
            tilde = stop
            while tilde > after and text[tilde - 1] in DIGIT_CHARS:
                tilde -= 1
            if after < tilde < stop and folded[tilde - 1] == RANGE_TILDE and not self._after_decimal_mark(text, tilde):
                chained = self._spaced_number(text, folded, chunks, last, True, confirm, at=tilde)
                if chained:
                    matches = [(start, after, piece, extra)] + self._values(text, after, tilde, folded)
                    return (head + self._split(text, folded, start, tilde, True, matches, (), confirm)[0]
                            + chained[0]), chained[1]
            matches = [(start, after, piece, extra)] + self._values(text, after, stop, folded)
            return head + self._split(text, folded, start, stop, True, matches, (), confirm)[0], last
        return None

    def _spaced_half(self, text, folded, chunks, k, reading, confirm):
        """047 규칙 34: pieces for chunk k when it is 반 alone, or 반 + registered suffix words
        (반에), written apart right after a value whose time unit 시·시간 ends the chunk before
        (3시 반·1시간 반에) — 반 is that value's unit mark. Else None."""
        _, start, end, kind = chunks[k]
        if kind != "word" or k == 0 or len(reading) < 2:
            return None
        prev, unit, value = chunks[k - 1], reading[-1], reading[-2]
        if (prev[3] != "word" or not text[prev[2]:start].isspace() or unit["kind"] != "word"
                or unit.get("category") != UNIT_CATEGORY or unit["end"] != prev[2]
                or fold_text(unit["text"]) not in HALF_AFTER
                or value["kind"] != "value" or value["end"] != unit["start"]):
            return None
        if confirm and self._confirmed(text, folded, start, end, confirm):
            return None
        for word in HALF_UNITS:
            if not folded.startswith(word, start, end):
                continue
            rest = start + len(word)
            tail = self._trailing(folded, rest, end, text) if rest < end else []
            if rest == end or (tail and tail[0]["start"] == rest
                               and all(w.get("attachment") == "suffix" for w in tail)):
                return [_unit_mark(text, start, rest)] + tail
        return None

    def _spaced_word(self, text, folded, chunks, k):
        """038 규칙 5 자리: (entry, last chunk index) when chunks k.. are exactly a
        registered word written with spaces (longest first), else None."""
        for size in range(min(self.spaced_max, len(chunks) - k), 1, -1):
            part = chunks[k:k + size]
            if any(c[3] != "word" for c in part) or any(
                    not text[a[2]:b[1]].isspace() for a, b in zip(part, part[1:])):
                continue
            entry = self.spaced.get(tuple(folded[c[1]:c[2]] for c in part))
            if entry:
                return entry, k + size - 1
        return None

    def read(self, text, confirm=frozenset()):
        """The one reading, as a list of one (the connector's listing shape).
        confirm: usable confirm words (confirm_set's first value)."""
        if not isinstance(text, str) or not text.strip():
            raise ValueError("nonempty text required")
        if len(text) > 4096:
            raise ValueError("text exceeds 4096 characters")
        confirm = frozenset(confirm)
        folded = fold_text(text)
        reading, left_any = [], False
        chunks = list(_chunks(text, self.symbols))
        k = 0
        while k < len(chunks):
            chunk, start, end, kind = chunks[k]
            if kind == "punctuation":
                reading.append({"kind": "punct", "text": chunk, "start": start, "end": end})
                left_any = False
                k += 1
                continue
            half = self._spaced_half(text, folded, chunks, k, reading, confirm)
            if half:
                reading.extend(half)
                left_any = True
                k += 1
                continue
            spaced = self._spaced_word(text, folded, chunks, k)
            if spaced:
                entry, last = spaced
                reading.append(self._word(entry, start, chunks[last][2], text))
                left_any = True
                k = last + 1
                continue
            number = self._spaced_number(text, folded, chunks, k, left_any, confirm)
            if number:
                pieces, last = number
                reading.extend(pieces)
                left_any = True
                k = last + 1
                continue
            reading.extend(self._chunk(text, folded, start, end, left_any, confirm))
            left_any = True
            k += 1
        if len(reading) > self.MAX_PIECES:
            raise PromiseLimit("PIECES")
        return [reading]
